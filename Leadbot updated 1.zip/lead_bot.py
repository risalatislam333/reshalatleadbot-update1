"""
Reshalat Lead Finder - Desktop Edition  (v2, high-throughput)
=============================================================
Mode A: describe a niche + location ("1000 salons in New York") -> the bot finds
        businesses, deep-crawls their sites IN PARALLEL and extracts contact data.
Mode B: upload CSV/Excel (or paste text) with company names/websites -> same
        deep crawl fills in the missing contact details.

Run:  python lead_bot.py
Data: ./data/history.json (no-repeat history), ./data/config.json (settings)
Out : ./output/  <prompt>_1_50.xlsx, <prompt>_51_100.xlsx ... (every 50 leads),
                 <prompt>_FULL_*.xlsx (everything), data/checkpoint_*.jsonl (crash-proof log),
                 rejected_*.csv (every discarded lead + the reason)

Rules enforced on every exported lead
-------------------------------------
* BOTH an email AND a phone number are required, otherwise the lead is discarded.
* Email must be published on the company's own site AND belong to the company
  (same domain, or a free-mail address the company itself publishes as its
  contact) AND its domain must accept mail (MX/A check).
* Phone must be a valid number (libphonenumber) published on the company's site
  (or corroborated by two independent directory snippets in fallback mode).
* Decision-maker (founder/owner/CEO/...) is targeted first. If no individual is
  found, the lead is kept with the company's official email + main phone and
  Name/Title = "Management / Team". Nothing is guessed or invented.
"""

import csv
import html as html_lib
import json
import os
import queue
import random
import re
import threading
import time
import traceback
import unicodedata
import urllib.robotparser as robotparser
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

try:  # GUI libs are optional so the engine can run/tests headless
    import customtkinter as ctk
    from tkinter import filedialog, messagebox
except Exception:  # pragma: no cover
    ctk = None
    filedialog = messagebox = None

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass

try:
    import lxml  # noqa: F401
    PARSER = "lxml"
except ImportError:
    PARSER = "html.parser"

try:
    import phonenumbers
except ImportError:
    phonenumbers = None

try:
    import dns.resolver as dns_resolver
except ImportError:
    dns_resolver = None

try:
    from ddgs import DDGS
except ImportError:
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        DDGS = None

try:
    from google import genai
    from google.genai import types as genai_types
except ImportError:
    genai = None
    genai_types = None

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
OUT_DIR = APP_DIR / "output"
HISTORY_FILE = DATA_DIR / "history.json"
CONFIG_FILE = DATA_DIR / "config.json"
SESSION_FILE = DATA_DIR / "session.json"
for _d in (DATA_DIR, OUT_DIR):
    _d.mkdir(exist_ok=True)

BATCH_SIZE = 10                  # checkpoint CSV every N kept leads
DEFAULT_WORKERS = 8              # sites crawled in parallel
MAX_PAGES = 7                    # pages crawled per site (home + 6)
PAGE_DELAY = (0.15, 0.4)         # tiny pause between pages of the SAME site
SEARCH_MIN_INTERVAL = 4.0        # seconds between web searches (global, auto-slows on errors)
HISTORY_SAVE_EVERY = 20          # save history.json every N processed sites
MICRO_SAVE = 10                  # also save history.json every N kept leads
XLSX_BATCH = 50                  # auto-save a formatted .xlsx every N leads
FETCH_TIMEOUT = (6, 12)          # connect, read
MAX_HTML = 1_500_000
DEFAULT_GEMINI_RPM = 10

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# Gemini: these families are shut down / retired -> never used, even if saved in old config
DEAD_MODEL_PREFIXES = ("gemini-1.", "gemini-2.0", "gemini-2.5", "gemini-pro", "gemini-exp")
PREFERRED_MODELS = [
    "gemini-3.1-flash-lite",       # stable, fastest, best free quota
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-3-flash-preview",
    "gemini-flash-lite-latest",
    "gemini-flash-latest",
]

CORE_COLUMNS = [  # (key, header, kind)
    ("business_name", "Business Name", "text"),
    ("first_name", "First Name", "text"),
    ("last_name", "Last Name", "text"),
    ("role", "Role/Title", "text"),
    ("email", "Email", "email"),
    ("phone", "Phone", "text"),
    ("website", "Website", "url"),
    ("linkedin", "LinkedIn Profile", "url"),
]
SOCIAL_COLUMNS = [
    ("facebook", "Facebook", "url"),
    ("instagram", "Instagram", "url"),
    ("twitter", "X / Twitter", "url"),
    ("youtube", "YouTube", "url"),
    ("tiktok", "TikTok", "url"),
]
TAIL_COLUMNS = [
    ("contact_level", "Contact Level", "text"),
    ("verification", "Verification", "text"),
]
BASE_KEYS = [c[0] for c in CORE_COLUMNS + SOCIAL_COLUMNS + TAIL_COLUMNS] + ["address", "linkedin_label"]

CORE_SYNONYMS = {
    "business name", "company name", "company", "business", "name", "first name", "last name",
    "role", "title", "job title", "role/title", "email", "e-mail", "phone", "telephone",
    "phone number", "mobile", "website", "url", "site", "linkedin", "linkedin profile",
    "social", "social media", "facebook", "instagram", "twitter", "x", "youtube", "tiktok",
}
ADDRESS_WORDS = {"address", "street address", "location", "office address", "mailing address",
                 "business address", "hq address", "headquarters", "full address"}

HEADER_ALIASES = {
    "business_name": ["business name", "company", "company name", "name", "business", "organization", "organisation"],
    "website": ["website", "url", "site", "domain", "web", "link", "web address"],
    "email": ["email", "e-mail", "email address"],
    "phone": ["phone", "telephone", "tel", "mobile", "phone number"],
    "first_name": ["first name", "firstname", "first"],
    "last_name": ["last name", "lastname", "last", "surname"],
    "role": ["role", "title", "job title", "role/title", "position"],
    "linkedin": ["linkedin", "linkedin profile"],
}

BLOCKED_DOMAINS = {
    "yelp.com", "facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com",
    "tripadvisor.com", "yellowpages.com", "mapquest.com", "groupon.com", "pinterest.com",
    "youtube.com", "tiktok.com", "reddit.com", "wikipedia.org", "bbb.org", "foursquare.com",
    "indeed.com", "glassdoor.com", "crunchbase.com", "apple.com", "amazon.com", "ebay.com",
    "etsy.com", "zocdoc.com", "vagaro.com", "fresha.com", "booksy.com", "thumbtack.com",
    "angi.com", "houzz.com", "nextdoor.com", "eventbrite.com", "manta.com", "superpages.com",
    "cylex.us.com", "clutch.co", "goodfirms.co", "medium.com", "quora.com", "forbes.com",
    "nytimes.com", "yahoo.com", "bing.com", "duckduckgo.com", "healthgrades.com", "zillow.com",
    "realtor.com", "trulia.com", "expedia.com", "booking.com", "opentable.com", "doordash.com",
    "ubereats.com", "grubhub.com", "wix.com", "squarespace.com", "wordpress.com", "weebly.com",
    "linktr.ee", "g.page", "goo.gl", "maps.app.goo.gl", "bestprosintown.com", "chamberofcommerce.com",
}

FREEMAIL = {"gmail.com", "googlemail.com", "yahoo.com", "ymail.com", "outlook.com", "hotmail.com",
            "live.com", "msn.com", "aol.com", "icloud.com", "me.com", "protonmail.com", "proton.me",
            "gmx.com", "mail.com", "yandex.com", "zoho.com", "comcast.net", "att.net", "verizon.net"}

GENERIC_LOCALS = {
    "info", "contact", "hello", "support", "sales", "admin", "office", "enquiries", "inquiries",
    "mail", "team", "help", "service", "booking", "bookings", "reception", "hi", "customerservice",
    "care", "orders", "marketing", "press", "jobs", "careers", "hr", "billing", "accounts",
    "webmaster", "noreply", "no-reply", "donotreply", "appointments", "frontdesk", "enquiry",
}
COMPANY_LOCALS = {"info", "contact", "hello", "office", "enquiries", "inquiries", "enquiry", "sales",
                  "admin", "mail", "reception", "appointments", "booking", "bookings", "frontdesk",
                  "service", "customerservice", "team", "care", "hi", "support", "help"}
BAD_LOCALS = {"noreply", "no-reply", "donotreply", "do-not-reply", "webmaster", "postmaster", "abuse",
              "privacy", "unsubscribe", "careers", "jobs", "hr", "press", "mailer-daemon", "root",
              "wordpress", "legal", "dpo", "gdpr", "security", "billing", "accounts"}
JUNK_LOCALS = {"you", "your", "name", "email", "test", "user", "username", "yourname", "example",
               "sentry", "john.doe", "jane.doe", "firstname", "lastname", "someone", "mail"}
JUNK_DOMAINS = {"example.com", "domain.com", "email.com", "sentry.io", "wixpress.com",
                "sentry-next.wixpress.com", "yoursite.com", "yourdomain.com", "mysite.com",
                "website.com", "company.com", "godaddy.com", "squarespace.com", "wix.com"}
JUNK_TLDS = {"png", "jpg", "jpeg", "gif", "svg", "webp", "css", "js", "ico", "woff", "woff2", "pdf", "mp4"}
JUNK_HANDLES = {"wix", "squarespace", "wordpress", "godaddy", "shopify", "facebook", "instagram",
                "twitter", "youtube", "linkedin", "tiktok", "sharer", "share", "intent", "home"}

PARKED_HINTS = ("domain is for sale", "buy this domain", "this domain may be for sale",
                "domain parking", "parked free", "this site can't be reached", "sedoparking")

ROLE_PATTERNS = [  # ordered by decision-maker priority
    r"(?:co-?)?founder", r"(?:co-?)?owner|proprietor", r"ceo|chief executive(?: officer)?",
    r"managing director", r"president|principal", r"managing partner|managing member",
    r"executive director", r"general manager", r"partner", r"director", r"manager",
]
ROLE_WORDS = (r"(?:co-?founder|founder|co-?owner|owner|proprietor|ceo|chief executive(?: officer)?|"
              r"managing director|managing partner|managing member|president|principal|"
              r"executive director|general manager|partner|director|manager)")
ROLE_RE = re.compile(r"\b" + ROLE_WORDS + r"\b", re.I)
DEPT_RE = re.compile(r"\b(marketing|sales|hr|human resources|finance|operations|it|technology|product|"
                     r"engineering|business development|development|creative|brand|digital|account|"
                     r"project|social media|community|office|store|branch|regional|area|district|"
                     r"program|event|customer|client|membership|practice|clinical|nursing|medical)\b", re.I)

NAME_STOP = {
    "our", "team", "meet", "the", "about", "us", "contact", "owner", "founder", "ceo", "president",
    "director", "manager", "office", "staff", "leadership", "management", "board", "directors",
    "partners", "founders", "welcome", "home", "get", "touch", "call", "email", "phone", "book",
    "now", "free", "new", "best", "top", "read", "more", "learn", "view", "click", "here", "privacy",
    "policy", "terms", "careers", "jobs", "blog", "news", "shop", "store", "dental", "law", "legal",
    "health", "care", "salon", "spa", "studio", "inc", "llc", "ltd", "corp", "co", "services",
    "service", "group", "company", "clinic", "center", "centre", "and", "or", "of", "for", "with",
    "your", "my", "we", "you", "in", "at", "to", "a", "an", "is", "chief", "executive", "officer",
    "managing", "general", "principal", "partner", "proprietor", "co-founder", "cofounder",
}
NAME_PARTICLES = {"de", "la", "van", "von", "da", "del", "di", "bin", "al", "el", "le", "du", "dos", "der"}
CRED_RE = re.compile(r"^(?:dds|dmd|md|do|phd|dvm|esq|cpa|jd|mba|rn|np|pa|pe|cfp|chfc|llc|inc|jr|sr|ii|iii)\.?$", re.I)

NAME_TOKEN = r"[A-Z][a-z]+(?:[\u2019'\-][A-Z]?[a-z]+)*"
NAMERX = NAME_TOKEN + r"(?:\s+[A-Z]\.)?\s+" + NAME_TOKEN
INLINE_ROLE_RE = re.compile(
    r"(?P<name>" + NAMERX + r")\s*,?\s+(?:is|serves as|works as|acts as)\s+(?:the\s+|our\s+|a\s+|an\s+)?"
    r"(?P<role>(?i:" + ROLE_WORDS + r")(?:\s*(?:and|&|/)\s*(?i:" + ROLE_WORDS + r"))*)\b")
FOUNDED_RE = re.compile(
    r"(?i:\b(?P<verb>founded|owned|started|established|opened|run|operated|led)\s+by)\s+"
    r"(?:(?i:dr|mr|mrs|ms)\.?\s+)?(?P<name>" + NAMERX + r")")

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,24}")
EMAIL_FULL_RE = re.compile(r"^[a-z0-9._%+\-]+@[a-z0-9\-]+(\.[a-z0-9\-]+)*\.[a-z]{2,24}$")
OBFUSCATED_RE = re.compile(
    r"([A-Za-z0-9._%+\-]+)\s*[\[\(\{]\s*at\s*[\]\)\}]\s*([A-Za-z0-9.\-]+)\s*[\[\(\{]\s*dot\s*[\]\)\}]\s*([A-Za-z]{2,})",
    re.I)
PHONE_RE = re.compile(r"(?<![\w/.\-])(?:\+|\()?\d(?:[\d().\-]|[ ](?=[\d(])){6,18}\d(?!\w)")
PHONE_LABEL_RE = re.compile(r"(phone|tel|call|mobile|office|main|direct|hotline|t:|p:)\W{0,3}$", re.I)
JSON_PHONE_RE = re.compile(r'"(?:telephone|phone|phoneNumber|contactPhone|tel)"\s*:\s*"([^"]{7,30})"', re.I)
DATE_LIKE_RE = re.compile(r"^\s*(?:\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})\s*$")
ADDR_US_RE = re.compile(r"\b\d{1,6}\s+[A-Za-z0-9.'\- ]{3,60},\s*[A-Za-z.'\- ]{2,40},\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?\b")

SKIP_EXT = (".pdf", ".jpg", ".jpeg", ".png", ".gif", ".svg", ".webp", ".zip", ".doc", ".docx",
            ".xls", ".xlsx", ".mp4", ".mp3", ".css", ".js", ".ico", ".xml")
LINK_RANKS = [  # (rank, hint words)  lower rank = crawled first
    (0, ("contact", "kontakt", "impressum", "reach-us", "get-in-touch", "connect")),
    (1, ("team", "leadership", "staff", "people", "management", "meet", "our-people", "doctors",
         "attorneys", "executive", "founder", "owner")),
    (2, ("about", "our-story", "story", "who-we-are", "company")),
]
PROBES_CONTACT = ["/contact", "/contact-us"]
PROBES_ABOUT = ["/about", "/about-us", "/our-team", "/team"]
PROBES_EMAIL = ["/privacy-policy", "/privacy", "/terms"]

SRC_W = {"mailto": 4.0, "jsonld": 4.0, "itemprop": 4.0, "cf": 4.0, "hf": 3.0, "text": 2.0, "source": 1.0}
PHONE_W = {"tel": 5.0, "jsonld": 5.0, "itemprop": 4.5, "label": 4.0, "hf": 3.5, "text": 2.0, "source": 1.0}


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json_atomic(path, obj):
    path = Path(path)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def norm_domain(url):
    if not url:
        return ""
    if not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    host = urlparse(url).netloc.lower().split("@")[-1].split(":")[0]
    return host[4:] if host.startswith("www.") else host


def norm_name(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def root_url(url):
    if not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}"


def is_blocked_host(host):
    if re.search(r"(^|\.)(google|bing|yahoo|duckduckgo)\.", host):
        return True
    return any(host == b or host.endswith("." + b) for b in BLOCKED_DOMAINS)


def sleep_stop(seconds, stop=None):
    end = time.time() + seconds
    while True:
        left = end - time.time()
        if left <= 0 or (stop is not None and stop.is_set()):
            return
        time.sleep(min(0.2, left))


def sleep_range(rng, stop=None):
    sleep_stop(random.uniform(*rng), stop)


def ascii_fold(s):
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode()


def clean_email(e):
    e = html_lib.unescape(unquote(e or "")).strip()
    e = re.sub(r"^mailto:", "", e, flags=re.I)
    e = e.strip(".,;:<>()[]'\" ").lower()
    e = re.sub(r"^(u00[0-9a-f]{2})+", "", e)
    if not EMAIL_FULL_RE.match(e):
        return ""
    local, _, dom = e.rpartition("@")
    tld = dom.rsplit(".", 1)[-1]
    if tld in JUNK_TLDS or local in JUNK_LOCALS or ".." in e:
        return ""
    if any(dom == d or dom.endswith("." + d) for d in JUNK_DOMAINS):
        return ""
    return e


def decode_cfemail(hexstr):
    try:
        key = int(hexstr[:2], 16)
        return "".join(chr(int(hexstr[i:i + 2], 16) ^ key) for i in range(2, len(hexstr), 2))
    except Exception:
        return ""


def emails_from_text(text):
    found = [clean_email(e) for e in EMAIL_RE.findall(text or "")]
    for m in OBFUSCATED_RE.finditer(text or ""):
        found.append(clean_email(f"{m.group(1)}@{m.group(2)}.{m.group(3)}"))
    return [e for e in dict.fromkeys(found) if e]


def normalize_phone(raw, region="US"):
    raw = (raw or "").strip()
    digits = re.sub(r"\D", "", raw)
    if not 8 <= len(digits) <= 15 or DATE_LIKE_RE.match(raw):
        return ""
    if len(set(digits)) <= 2:
        return ""
    if phonenumbers is None:
        ok = (re.search(r"[\s().\-]", raw) or raw.startswith("+")) and 10 <= len(digits) <= 15
        return raw if ok else ""
    try:
        n = phonenumbers.parse(raw, region)
        if phonenumbers.is_valid_number(n):
            return phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
    except Exception:
        pass
    return ""


def phones_from_text(text, region="US"):
    """[(phone, labeled_bool)] - skips fax numbers, dates and glued tokens."""
    out, seen = [], set()
    for m in PHONE_RE.finditer(text or ""):
        before = text[max(0, m.start() - 22):m.start()].lower()
        if "fax" in before[-10:]:
            continue
        p = normalize_phone(m.group(0), region)
        if p and p not in seen:
            seen.add(p)
            out.append((p, bool(PHONE_LABEL_RE.search(before))))
    return out


def role_rank(role):
    r = (role or "").lower().strip()
    if not r or len(r) > 90:
        return 99
    if re.search(r"\b(vice|vp|assistant|associate|deputy|former|retired|past|interim|junior)\b", r):
        return 99
    for i, pat in enumerate(ROLE_PATTERNS):
        if re.search(r"\b(?:" + pat + r")\b", r):
            if pat in ("director", "manager") and (re.search(r"\b(of|for)\b", r) or DEPT_RE.search(r)):
                return 99
            return i
    return 99


def clean_person_name(s):
    s = re.sub(r"^(?:dr|mr|mrs|ms|miss|prof)\.?\s+", "", (s or "").strip(), flags=re.I)
    toks = [t for t in s.replace(",", " ").split() if not CRED_RE.match(t)]
    return " ".join(toks)


def looks_like_name(s):
    s = clean_person_name(s)
    if not s or len(s) > 40:
        return False
    if s.isupper():
        s = s.title()
    toks = s.split()
    if not 2 <= len(toks) <= 4:
        return False
    real = 0
    for t in toks:
        if re.fullmatch(r"[^\W\d_]\.?", t):
            continue
        if t.lower() in NAME_PARTICLES:
            continue
        if not re.fullmatch(r"[^\W\d_][^\W\d_'\u2019]*(?:[-'\u2019][^\W\d_]+)*\.?", t):
            return False
        if not t[0].isupper() or t.lower().strip(".") in NAME_STOP:
            return False
        real += 1
    return real >= 2


def split_name(full):
    s = clean_person_name(full)
    if s.isupper():
        s = s.title()
    toks = [t for t in s.split() if not re.fullmatch(r"[^\W\d_]\.?", t)] or s.split()
    if len(toks) < 2:
        return (toks[0] if toks else ""), ""
    return toks[0], " ".join(toks[1:])


def clean_title(title, domain):
    segs = [s.strip() for s in re.split(r"\s[\|\-\u2013\u2014:\u2022\u00b7]\s", title or "") if s.strip()]
    if not segs:
        return ""
    label = domain.split(".")[0].replace("-", "")
    for s in segs:
        n = norm_name(s).replace(" ", "")
        if n and (n in label or label in n):
            return s
    return segs[0]


def slugify(s):
    return re.sub(r"[^a-z0-9]+", "_", (s or "").lower()).strip("_")


def domain_match(dom, site_domains):
    return any(dom == sd or dom.endswith("." + sd) or sd.endswith("." + dom) for sd in site_domains)


def person_email_patterns(first, last):
    f, l = re.sub(r"[^a-z]", "", ascii_fold(first).lower()), re.sub(r"[^a-z]", "", ascii_fold(last.split()[-1] if last else "").lower())
    if not f or not l:
        return set()
    pats = {f, l, f + l, f + "." + l, f[0] + l, f[0] + "." + l, f + l[0], f + "." + l[0],
            f + "_" + l, f + "-" + l, l + f, l + "." + f, f[0] + "_" + l}
    return {p for p in pats if len(p) >= 3}


def classify_social(href):
    """-> (platform, normalized_url) or None."""
    try:
        p = urlparse(href if "//" in href else "https://" + href)
    except Exception:
        return None
    host = re.sub(r"^(www|m|mobile|web|en-gb|en)\.", "", p.netloc.lower().split(":")[0])
    segs = [s for s in p.path.split("/") if s]
    if not segs or not host:
        return None
    first = segs[0]
    low = first.lower()
    if host == "linkedin.com" or host.endswith(".linkedin.com"):
        if low == "in" and len(segs) > 1:
            return "linkedin_person", f"https://www.linkedin.com/in/{segs[1]}"
        if low in ("company", "school") and len(segs) > 1:
            return "linkedin_company", f"https://www.linkedin.com/{low}/{segs[1]}"
        return None
    if host in ("facebook.com", "fb.com"):
        if low in JUNK_HANDLES or low in ("tr", "dialog", "plugins", "policy", "help", "login", "events", "watch", "groups"):
            return None
        if low == "profile.php" and p.query:
            return "facebook", "https://www.facebook.com/profile.php?" + p.query.split("&")[0]
        if low in ("pages", "people", "p") and len(segs) > 1:
            return "facebook", "https://www.facebook.com/" + "/".join(segs[:3])
        return "facebook", f"https://www.facebook.com/{first}"
    if host == "instagram.com":
        if low in ("p", "explore", "accounts", "reel", "reels", "stories", "tv") or low in JUNK_HANDLES:
            return None
        return "instagram", f"https://www.instagram.com/{first}/"
    if host in ("twitter.com", "x.com"):
        if low in ("intent", "share", "home", "i", "hashtag", "search", "widgets.js") or low in JUNK_HANDLES:
            return None
        return "twitter", f"https://x.com/{first}"
    if host == "youtube.com":
        if low in ("channel", "c", "user") and len(segs) > 1:
            return "youtube", f"https://www.youtube.com/{low}/{segs[1]}"
        if low.startswith("@"):
            return "youtube", f"https://www.youtube.com/{first}"
        return None
    if host == "tiktok.com" and low.startswith("@"):
        return "tiktok", f"https://www.tiktok.com/{first}"
    return None


def regex_parse_prompt(prompt):
    """Fallback prompt parser when Gemini is unavailable."""
    count = 100
    m = re.search(r"\b(\d[\d,]*)\b", prompt)
    if m:
        count = int(m.group(1).replace(",", ""))
    text = re.sub(r"\b\d[\d,]*\b", "", prompt, count=1)
    parts = re.split(r"\s+(?:in|near|around|at)\s+", text, maxsplit=1, flags=re.I)
    niche = re.sub(r"\b(find|get|me|scrape|generate|leads?|of|for|list|a|the|please|b2b|companies|businesses)\b",
                   "", parts[0], flags=re.I)
    niche = re.sub(r"\s+", " ", niche).strip(" ,.-")
    location = ""
    if len(parts) > 1:
        location = re.split(r"[.;\n]|\bwith\b|\bcolumns?\b|\binclude\b", parts[1], maxsplit=1, flags=re.I)[0].strip(" ,.-")
    cols = []
    cm = re.search(r"columns?\s*[:\-]\s*(.+)", prompt, re.I)
    if cm:
        cols = [c.strip() for c in re.split(r",|;|\band\b", cm.group(1)) if c.strip()]
    implicit = [(r"\baddress(?:es)?\b", "Address"),
                (r"employee (?:size|count)|number of employees|company size|headcount|team size", "Employee Size"),
                (r"\brevenue\b|annual sales", "Revenue"), (r"\bindustry\b", "Industry"),
                (r"year founded|founding year|founded in", "Year Founded")]
    for pat, label in implicit:
        if re.search(pat, prompt, re.I) and label.lower() not in [c.lower() for c in cols]:
            cols.append(label)
    return {"niche": niche, "location": location, "count": count, "columns": cols}


def split_requested_columns(names):
    """Requested extra columns -> list of (key, header). Core/social columns are always present."""
    out, seen = [], set()
    for raw in names or []:
        n = str(raw).strip()
        low = n.lower()
        if not n or low in CORE_SYNONYMS:
            continue
        key = "address" if low in ADDRESS_WORDS else "cf:" + slugify(n)
        if key in seen:
            continue
        seen.add(key)
        out.append((key, "Address" if key == "address" else n[:1].upper() + n[1:]))
    return out


# ---------------------------------------------------------------------------
# History (no-repeat) manager
# ---------------------------------------------------------------------------
class History:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.Lock()
        data = load_json(self.path, {})
        self.companies = data.get("companies", {})
        self.exhausted = set(data.get("exhausted_queries", []))

    def seen(self, key):
        with self.lock:
            return key in self.companies

    def add(self, key, meta):
        with self.lock:
            self.companies[key] = meta

    def query_exhausted(self, q):
        return q.lower() in self.exhausted

    def mark_exhausted(self, q):
        with self.lock:
            self.exhausted.add(q.lower())

    def clear(self):
        with self.lock:
            self.companies, self.exhausted = {}, set()
        self.save()

    def save(self):
        with self.lock:
            save_json_atomic(self.path, {"companies": self.companies,
                                         "exhausted_queries": sorted(self.exhausted)})

    def __len__(self):
        return len(self.companies)


# ---------------------------------------------------------------------------
# Gemini: model auto-discovery, dead-model blacklist, non-blocking rate limiting
# ---------------------------------------------------------------------------
class RateLimiter:
    """Reserve-a-slot limiter. reserve() returns the delay to wait, or None if the
    next free slot is further away than max_wait (caller then skips AI instead of stalling)."""

    def __init__(self, rpm):
        self.interval = 60.0 / max(1.0, float(rpm))
        self.next = 0.0
        self.lock = threading.Lock()

    def reserve(self, max_wait):
        with self.lock:
            now = time.time()
            start = max(now, self.next)
            if start - now > max_wait:
                return None
            self.next = start + self.interval
            return start - now


class Gemini:
    def __init__(self, api_key, model_pref, rpm, log, stop):
        self.log, self.stop = log, stop
        self.enabled = False
        self.client = None
        self.limiter = RateLimiter(rpm)
        self.dead, self.cool = set(), {}
        self.lock = threading.Lock()
        self.thinking_ok = True
        self.stats = {"calls": 0, "skipped": 0, "errors": 0}
        self.chain = []
        if api_key and genai is not None:
            try:
                try:
                    self.client = genai.Client(api_key=api_key,
                                               http_options=genai_types.HttpOptions(timeout=25000))
                except Exception:
                    self.client = genai.Client(api_key=api_key)
                self.enabled = True
                self._build_chain(model_pref)
            except Exception as e:
                log(f"Gemini init failed: {e}")
        elif api_key:
            log("google-genai is not installed - Gemini features disabled.")

    # ---- model selection ----
    @staticmethod
    def _usable(name):
        n = name.lower()
        if not n.startswith("gemini") or n.startswith(DEAD_MODEL_PREFIXES) or "flash" not in n:
            return False
        return not any(b in n for b in ("image", "tts", "live", "audio", "embedding", "robotics",
                                        "computer-use", "vision", "native", "learnlm", "exp"))

    def _build_chain(self, pref):
        avail = []
        try:
            for m in self.client.models.list():
                name = (getattr(m, "name", "") or "").replace("models/", "")
                acts = getattr(m, "supported_actions", None) or getattr(m, "supported_generation_methods", None) or []
                if acts and "generateContent" not in acts:
                    continue
                if self._usable(name):
                    avail.append(name)
        except Exception as e:
            self.log(f"Gemini model discovery failed ({str(e)[:70]}) - using built-in list.")
        chain = []
        pref = (pref or "").strip()
        if pref and pref.lower() != "auto" and not pref.lower().startswith(DEAD_MODEL_PREFIXES):
            chain.append(pref.replace("models/", ""))
        elif pref and pref.lower() != "auto":
            self.log(f"Configured model '{pref}' is retired - switching to auto-selection.")
        for m in PREFERRED_MODELS:
            if (not avail or m in avail) and m not in chain:
                chain.append(m)
        for m in sorted(avail, reverse=True):
            if m not in chain:
                chain.append(m)
        self.chain = chain
        self.log("Gemini model order: " + ", ".join(chain[:4]) + (" ..." if len(chain) > 4 else ""))

    def _next_model(self, tried):
        now = time.time()
        with self.lock:
            for m in self.chain:
                if m in self.dead or m in tried or self.cool.get(m, 0) > now:
                    continue
                return m
        return None

    def _config(self):
        kw = {"response_mime_type": "application/json"}
        if self.thinking_ok:
            try:
                kw["thinking_config"] = genai_types.ThinkingConfig(thinking_level="low")
            except Exception:
                self.thinking_ok = False
        return genai_types.GenerateContentConfig(**kw)

    @staticmethod
    def _classify(e):
        code = getattr(e, "code", None) or getattr(e, "status_code", None)
        msg = str(e).lower()
        if code == 404 or "not_found" in msg or "no longer available" in msg or "is not found" in msg:
            return "dead", 0
        if code == 429 or "resource_exhausted" in msg or "quota" in msg:
            m = re.search(r"retry(?:delay)?\D{0,14}(\d+(?:\.\d+)?)\s*s", msg)
            per_day = "perday" in msg.replace(" ", "").replace("_", "")
            return "quota", (3600 if per_day else (float(m.group(1)) + 1 if m else 30))
        if code == 400 and "thinking" in msg:
            return "thinking", 0
        if code in (401, 403) or "api key" in msg or "permission" in msg:
            return "auth", 0
        if code in (500, 502, 503, 504) or any(k in msg for k in ("unavailable", "overloaded", "deadline", "timeout", "timed out")):
            return "transient", 8
        return "other", 0

    def _call(self, prompt, max_wait=3.0):
        """Returns parsed JSON or None. NEVER blocks longer than ~max_wait for a rate-limit slot."""
        if not self.enabled:
            return None
        tried, attempts = set(), 0
        while attempts < 6 and not self.stop.is_set():
            attempts += 1
            model = self._next_model(tried)
            if not model:
                self.stats["skipped"] += 1
                return None
            wait = self.limiter.reserve(max_wait)
            if wait is None:
                self.stats["skipped"] += 1
                return None
            sleep_stop(wait, self.stop)
            try:
                self.stats["calls"] += 1
                resp = self.client.models.generate_content(model=model, contents=prompt, config=self._config())
                txt = (resp.text or "").strip()
                txt = re.sub(r"^```(?:json)?|```$", "", txt, flags=re.M).strip()
                return json.loads(txt)
            except json.JSONDecodeError:
                return None
            except Exception as e:
                self.stats["errors"] += 1
                kind, delay = self._classify(e)
                if kind == "dead":
                    with self.lock:
                        self.dead.add(model)
                    self.log(f"Gemini model '{model}' unavailable (404) - switching instantly.")
                elif kind == "quota":
                    with self.lock:
                        self.cool[model] = time.time() + delay
                    self.log(f"Gemini '{model}' rate-limited - cooling {delay:.0f}s, trying next model.")
                elif kind == "transient":
                    with self.lock:
                        self.cool[model] = time.time() + delay
                elif kind == "thinking":
                    self.thinking_ok = False
                elif kind == "auth":
                    self.enabled = False
                    self.log(f"Gemini key rejected - AI features disabled: {str(e)[:100]}")
                    return None
                else:
                    tried.add(model)
                    self.log(f"Gemini error ({model}): {str(e)[:110]}")
        return None

    # ---- tasks ----
    def parse_prompt(self, prompt):
        data = self._call(
            "Extract lead-generation criteria from the request below. Return JSON with keys: "
            '"niche" (string), "location" (string), "count" (integer; 100 if not stated), '
            '"columns" (list of EXTRA data fields the user wants beyond business name, contact name, '
            "role, email, phone, website, LinkedIn and social links - e.g. Address, Employee Size, "
            "Revenue, Industry. Empty list if none).\n\nREQUEST:\n" + prompt, max_wait=25)
        if isinstance(data, dict) and data.get("niche"):
            try:
                data["count"] = int(data.get("count") or 100)
            except (TypeError, ValueError):
                data["count"] = 100
            data["location"] = str(data.get("location") or "")
            data["columns"] = [str(c) for c in data["columns"]] if isinstance(data.get("columns"), list) else []
            return data
        return None

    def suggest_expansion(self, niche, location):
        data = self._call(
            f'For finding local "{niche}" businesses in "{location}", return JSON with keys '
            '"niche_synonyms" (up to 5 alternative search terms for the same kind of business) and '
            '"areas" (up to 25 real neighbourhoods, districts or nearby towns inside/around the '
            "location). Only real place names.", max_wait=25)
        if isinstance(data, dict):
            syn = [s for s in data.get("niche_synonyms", []) if isinstance(s, str)]
            areas = [a for a in data.get("areas", []) if isinstance(a, str)]
            return {"niche_synonyms": syn[:5], "areas": areas[:25]}
        return {"niche_synonyms": [], "areas": []}

    def analyze_site(self, company, excerpt, want_people, want_fields):
        """One call -> decision-makers + custom fields, every value verified against the source text."""
        excerpt = excerpt[:6000]
        field_names = [f for f in want_fields]
        spec = []
        if want_people:
            spec.append('"people": [{"first_name":"","last_name":"","role":""}] - ONLY individuals explicitly '
                        "named together with an ownership/leadership role (founder, owner, CEO, president, "
                        "managing director, principal, partner, general manager)")
        if field_names:
            spec.append('"fields": {' + ", ".join(f'"{f}": ""' for f in field_names) +
                        "} - value ONLY if literally stated in the text, otherwise empty string")
        data = self._call(
            f'Text excerpts from the official website of "{company}". Return JSON with keys:\n- ' +
            "\n- ".join(spec) + "\nNever invent, infer or guess. Use only what the text literally says.\n\nTEXT:\n" + excerpt)
        out = {"people": [], "fields": {}}
        if not isinstance(data, dict):
            return out
        low = excerpt.lower()
        for p in data.get("people", []) or []:
            if not isinstance(p, dict):
                continue
            first, last = str(p.get("first_name") or "").strip(), str(p.get("last_name") or "").strip()
            role = str(p.get("role") or "").strip()
            if not first or not last or first.lower() not in low or last.lower() not in low:
                continue  # hallucination guard
            if role_rank(role) >= 99 or role.lower() not in low:
                continue
            out["people"].append((first, last, role))
        fields = data.get("fields")
        if isinstance(fields, dict):
            for k, v in fields.items():
                v = str(v or "").strip()
                if v and all(t in low for t in re.findall(r"[a-z0-9]+", v.lower())):
                    out["fields"][k] = v[:200]
        return out


# ---------------------------------------------------------------------------
# Web search (free, no API key) - globally throttled, shared by all threads
# ---------------------------------------------------------------------------
class SearchGate:
    """Global, serialized search with adaptive slow-down and a circuit breaker.
    search() -> list (empty = genuinely no results) or None (failed / blocked - NOT the same thing)."""
    MAX_PAUSES = 4

    def __init__(self, log, stop, interval=SEARCH_MIN_INTERVAL):
        self.log, self.stop = log, stop
        self.base = self.interval = interval
        self.lock = threading.Lock()
        self.last = 0.0
        self.pauses = 0
        self.blocked_out = False

    def search(self, query, max_results):
        if DDGS is None:
            self.log("No search library installed (pip install ddgs).")
            return None
        with self.lock:
            if self.blocked_out:
                return None
            for attempt in range(3):
                if self.stop.is_set():
                    return None
                sleep_stop(self.interval - (time.time() - self.last), self.stop)
                try:
                    self.last = time.time()
                    with DDGS() as d:
                        res = list(d.text(query, max_results=max_results)) or []
                    self.pauses = 0
                    self.interval = max(self.base, self.interval * 0.9)
                    return res
                except Exception as e:
                    if "no results" in str(e).lower():
                        return []
                    self.interval = min(60.0, max(self.interval * 2, 8.0))
                    wait = min(90, 8 * (2 ** attempt)) + random.uniform(0, 3)
                    self.log(f"Search rate-limited/failed ({str(e)[:60]}). Backing off {wait:.0f}s, "
                             f"new interval {self.interval:.0f}s ...")
                    sleep_stop(wait, self.stop)
            self.pauses += 1
            if self.pauses > self.MAX_PAUSES:
                self.blocked_out = True
                self.log("Search engine keeps refusing requests from this connection - stopping searches.")
                return None
            cool = 120 * self.pauses
            self.log(f"Search looks blocked - pausing ALL searching for {cool}s (pause {self.pauses}/{self.MAX_PAUSES}).")
            sleep_stop(cool, self.stop)
            return None


def acceptable_hit(url, title):
    if not url or not url.lower().startswith(("http://", "https://")):
        return False
    if is_blocked_host(norm_domain(url)):
        return False
    if re.search(r"\b(top|best)\s+\d+|\b\d+\s+best\b|\bdirectory\b|\bnear me\b", title or "", re.I):
        return False
    return True


# ---------------------------------------------------------------------------
# JavaScript renderer (Playwright lives in its own threads - sync API is not thread-safe)
# ---------------------------------------------------------------------------
class JSRenderer:
    def __init__(self, log, stop, threads=2):
        self.log, self.stop, self.n = log, stop, threads
        self.q = queue.Queue()
        self.ready = threading.Event()
        self.failed = False
        self.started = False
        self.lock = threading.Lock()
        self.threads = []

    def _ensure(self):
        with self.lock:
            if self.started:
                return
            self.started = True
            for _ in range(self.n):
                t = threading.Thread(target=self._run, daemon=True)
                t.start()
                self.threads.append(t)

    def _run(self):
        pw = browser = ctx = None
        try:
            from playwright.sync_api import sync_playwright
            pw = sync_playwright().start()
            browser = pw.chromium.launch(headless=True)
            ctx = browser.new_context(user_agent=UA)
            ctx.route("**/*", lambda r: r.abort()
                      if r.request.resource_type in ("image", "media", "font") else r.continue_())
            self.ready.set()
        except Exception as e:
            if not self.failed:
                self.log(f"Playwright unavailable ({str(e)[:80]}). Using plain HTTP only. "
                         "Run: playwright install chromium")
            self.failed = True
            self.ready.set()
            return
        while True:
            job = self.q.get()
            if job is None:
                break
            page = None
            try:
                page = ctx.new_page()
                page.goto(job["url"], wait_until="domcontentloaded", timeout=20000)
                page.wait_for_timeout(1200)
                job["out"] = (page.content(), page.url)
            except Exception:
                pass
            finally:
                try:
                    if page:
                        page.close()
                except Exception:
                    pass
                job["ev"].set()
        for obj, meth in ((ctx, "close"), (browser, "close"), (pw, "stop")):
            try:
                if obj:
                    getattr(obj, meth)()
            except Exception:
                pass

    def render(self, url):
        self._ensure()
        self.ready.wait(30)
        if self.failed or self.stop.is_set():
            return None
        job = {"url": url, "ev": threading.Event(), "out": None}
        self.q.put(job)
        job["ev"].wait(40)
        return job["out"]

    def close(self):
        for _ in self.threads:
            self.q.put(None)
        for t in self.threads:
            t.join(timeout=5)


# ---------------------------------------------------------------------------
# Fetcher: requests (fast path) + JS fallback, robots.txt aware, thread-safe
# ---------------------------------------------------------------------------
class Fetcher:
    def __init__(self, cfg, renderer, log, stop):
        self.cfg, self.renderer, self.log, self.stop = cfg, renderer, log, stop
        self.tl = threading.local()
        self.robots, self.rlock = {}, threading.Lock()

    def _session(self):
        s = getattr(self.tl, "s", None)
        if s is None:
            s = requests.Session()
            s.headers.update({"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9",
                              "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"})
            adapter = requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=4, max_retries=0)
            s.mount("http://", adapter)
            s.mount("https://", adapter)
            self.tl.s = s
        return s

    def allowed(self, url):
        if not self.cfg.get("respect_robots", True):
            return True
        p = urlparse(url)
        with self.rlock:
            rp = self.robots.get(p.netloc)
        if rp is None:
            rp = robotparser.RobotFileParser()
            try:
                r = self._session().get(f"{p.scheme}://{p.netloc}/robots.txt", timeout=6)
                rp.parse(r.text.splitlines() if r.status_code == 200 else [])
            except Exception:
                rp.parse([])
            with self.rlock:
                self.robots[p.netloc] = rp
        try:
            return rp.can_fetch(UA, url)
        except Exception:
            return True

    def http_get(self, url):
        """-> (text|None, final_url, status)"""
        s = self._session()
        r = None
        for verify in (True, False):
            try:
                r = s.get(url, timeout=FETCH_TIMEOUT, allow_redirects=True, verify=verify)
                break
            except requests.exceptions.SSLError:
                if verify:
                    continue
                return None, url, "ssl"
            except requests.exceptions.ConnectionError as e:
                msg = str(e).lower()
                dns = any(k in msg for k in ("name or service not known", "getaddrinfo", "nodename",
                                             "failed to resolve", "name resolution"))
                return None, url, "dns" if dns else "conn"
            except requests.exceptions.Timeout:
                return None, url, "timeout"
            except requests.RequestException:
                return None, url, "error"
        if r is None:
            return None, url, "error"
        ctype = r.headers.get("content-type", "").lower()
        if r.status_code == 200:
            if ctype and not any(t in ctype for t in ("html", "xml", "text")):
                return None, r.url, "type"
            if "charset" not in ctype:
                r.encoding = "utf-8"
            return r.text[:MAX_HTML], r.url, 200
        return None, r.url, r.status_code

    @staticmethod
    def _thin(html):
        txt = re.sub(r"(?is)<script.*?</script>|<style.*?</style>|<[^>]+>", " ", html)
        return len(re.sub(r"\s+", "", txt)) < 300

    def get_page(self, url):
        """-> (html|None, final_url, status)"""
        if self.stop.is_set():
            return None, url, "stop"
        if not self.allowed(url):
            return None, url, "robots"
        html, final, status = self.http_get(url)
        want_js = self.cfg.get("use_js", True) and status not in ("dns", 404, 410, "robots", "type", "stop")
        if want_js and (html is None or self._thin(html)):
            out = self.renderer.render(url)
            if out and out[0]:
                return out[0], out[1], 200
        return html, final, status


# ---------------------------------------------------------------------------
# Page analysis (pure functions of HTML)
# ---------------------------------------------------------------------------
def parse_jsonld(soup):
    out = {"name": "", "emails": [], "phones": [], "same_as": [], "people": [], "addresses": []}
    org_words = ("Organization", "Business", "Store", "Salon", "Restaurant", "Clinic", "Dentist",
                 "Agency", "Firm", "Gym", "Hotel", "School", "Service", "Practice", "Shop", "Company")
    for tag in soup.find_all("script", type=lambda t: t and "ld+json" in t):
        try:
            data = json.loads(tag.string or tag.get_text() or "")
        except Exception:
            continue
        stack = [data]
        while stack:
            node = stack.pop()
            if isinstance(node, list):
                stack.extend(node)
                continue
            if not isinstance(node, dict):
                continue
            if "@graph" in node:
                stack.append(node["@graph"])
            types = node.get("@type")
            types = [str(t) for t in (types if isinstance(types, list) else [types]) if t]
            if "Person" in types:
                nm = node.get("name")
                if isinstance(nm, str) and nm.strip():
                    out["people"].append({"name": nm.strip(), "role": str(node.get("jobTitle") or ""),
                                          "email": str(node.get("email") or ""),
                                          "phone": str(node.get("telephone") or "")})
            else:
                if isinstance(node.get("email"), str):
                    out["emails"].append(node["email"])
                if isinstance(node.get("telephone"), str):
                    out["phones"].append(node["telephone"])
                sa = node.get("sameAs")
                sa = [sa] if isinstance(sa, str) else sa
                if isinstance(sa, list):
                    out["same_as"].extend(s for s in sa if isinstance(s, str))
                if (not out["name"] and isinstance(node.get("name"), str)
                        and any(w in t for t in types for w in org_words)):
                    out["name"] = node["name"].strip()
                addr = node.get("address")
                if isinstance(addr, dict):
                    ctry = addr.get("addressCountry")
                    ctry = ctry.get("name") if isinstance(ctry, dict) else ctry
                    parts = [addr.get("streetAddress"), addr.get("addressLocality"), addr.get("addressRegion"),
                             addr.get("postalCode"), ctry]
                    s = ", ".join(str(p).strip() for p in parts if p and isinstance(p, (str, int)))
                    if s:
                        out["addresses"].append(s)
                elif isinstance(addr, str) and addr.strip():
                    out["addresses"].append(addr.strip())
            for key, default_role in (("founder", "Founder"), ("founders", "Founder"), ("employee", ""),
                                      ("member", ""), ("mainEntity", ""), ("contactPoint", "")):
                child = node.get(key)
                for c in (child if isinstance(child, list) else [child]):
                    if not isinstance(c, dict):
                        continue
                    if key == "contactPoint":
                        stack.append(c)
                        continue
                    c = dict(c)
                    c.setdefault("@type", "Person")
                    if default_role and not c.get("jobTitle"):
                        c["jobTitle"] = default_role
                    stack.append(c)
    return out


def people_from_lines(lines, text):
    """Heuristic decision-maker extraction -> [(first, last, role)] (structure-based, no AI)."""
    found = []

    def add(name, role):
        name = clean_person_name(name)
        role = re.sub(r"\s+", " ", role).strip(" ,.-|")[:70]
        if looks_like_name(name) and role_rank(role) < 99:
            f, l = split_name(name)
            if f and l:
                found.append((f, l, role))

    n = len(lines)
    for i, line in enumerate(lines):
        if len(line) > 120 or not ROLE_RE.search(line):
            continue
        parts = [p.strip() for p in re.split(r"\s*[,|\u2013\u2014\u2022\u00b7:]\s*|\s+-\s+", line) if p.strip()]
        parts = [p for p in parts if not CRED_RE.match(p)]
        hit = False
        for j in range(len(parts) - 1):
            if looks_like_name(parts[j]) and ROLE_RE.search(parts[j + 1]):
                add(parts[j], parts[j + 1])
                hit = True
            elif ROLE_RE.search(parts[j]) and looks_like_name(parts[j + 1]):
                add(parts[j + 1], parts[j])
                hit = True
        if hit or len(line) > 60 or looks_like_name(line):
            continue
        # role-only line -> name sits on the previous (or next) line of the card
        if i > 0 and looks_like_name(lines[i - 1]):
            add(lines[i - 1], line)
        elif i + 1 < n and looks_like_name(lines[i + 1]):
            add(lines[i + 1], line)
    for m in INLINE_ROLE_RE.finditer(text):
        add(m.group("name"), m.group("role"))
    for m in FOUNDED_RE.finditer(text):
        verb = m.group("verb").lower()
        add(m.group("name"), "Owner" if verb in ("owned", "run", "operated") else "Founder")
    return list(dict.fromkeys(found))


def card_contacts(soup, first, last):
    """Email/phone/LinkedIn that sit in the same small 'card' as the person's name."""
    pat = re.compile(re.escape(first) + r"[\s\w.'\u2019\-]{0,20}" + re.escape(last.split()[-1]), re.I)
    node = soup.find(string=pat)
    if node is None:
        return {}
    el = node.parent
    for _ in range(4):
        if el is None or el.name in ("body", "html", "[document]"):
            break
        txt = el.get_text(" ", strip=True)
        if len(txt) > 700 or len(ROLE_RE.findall(txt)) > 2:
            break
        emails, phones, li = [], [], ""
        for a in el.find_all("a", href=True):
            h = a["href"].strip()
            hl = h.lower()
            if hl.startswith("mailto:"):
                emails += [clean_email(x) for x in unquote(h[7:]).split("?")[0].split(",")]
            elif hl.startswith("tel:"):
                phones.append(unquote(h[4:]))
            elif "linkedin.com/in/" in hl:
                li = h
        emails += emails_from_text(txt)
        emails = [e for e in dict.fromkeys(emails) if e]
        if emails or phones or li:
            return {"emails": emails, "phones": phones, "linkedin": li}
        el = el.parent
    return {}


def analyze_page(html, url, kind, region, field_kw):
    soup = BeautifulSoup(html, PARSER)
    info = {"url": url, "kind": kind, "emails": [], "phones": [], "people": [], "socials": {},
            "li_people": [], "address": "", "name": "", "links": [], "windows": "", "text_len": 0}
    jl = parse_jsonld(soup)
    raw = html_lib.unescape(html)

    # --- anchors: mailto / tel / cloudflare-protected / socials / crawl links
    anchors = []
    for a in soup.find_all("a", href=True):
        h = a["href"].strip()
        hl = h.lower()
        if hl.startswith("mailto:"):
            for x in unquote(h[7:]).split("?")[0].split(","):
                info["emails"].append((clean_email(x), "mailto"))
        elif hl.startswith("tel:"):
            info["phones"].append((normalize_phone(unquote(h[4:]), region), "tel"))
        elif "/cdn-cgi/l/email-protection#" in hl:
            info["emails"].append((clean_email(decode_cfemail(h.split("#")[-1])), "cf"))
        elif not hl.startswith(("javascript:", "#", "sms:", "whatsapp:")):
            anchors.append((urljoin(url, h).split("#")[0], a.get_text(" ", strip=True)))
    for el in soup.select("[data-cfemail]"):
        info["emails"].append((clean_email(decode_cfemail(el.get("data-cfemail", ""))), "cf"))
    for el in soup.select('[itemprop="email"], [itemprop="telephone"]'):
        val = el.get("content") or el.get_text(strip=True)
        if el.get("itemprop") == "email":
            info["emails"].append((clean_email(val), "itemprop"))
        else:
            info["phones"].append((normalize_phone(val, region), "itemprop"))
    info["emails"] += [(clean_email(e), "jsonld") for e in jl["emails"]]
    info["phones"] += [(normalize_phone(p, region), "jsonld") for p in jl["phones"]]
    info["phones"] += [(normalize_phone(m, region), "source") for m in JSON_PHONE_RE.findall(raw)]
    info["emails"] += [(e, "source") for e in emails_from_text(raw)]

    # --- socials (company-level)
    li_people = []
    for href in [h for h, _ in anchors] + jl["same_as"]:
        c = classify_social(href)
        if not c:
            continue
        if c[0] == "linkedin_person":
            li_people.append(c[1])
        else:
            info["socials"].setdefault(c[0], c[1])
    info["li_people"] = list(dict.fromkeys(li_people))

    # --- visible text
    for t in soup(["script", "style", "noscript", "template"]):
        t.decompose()
    lines = [l.strip() for l in soup.get_text("\n", strip=True).split("\n") if l.strip()]
    text = " ".join(lines)
    info["text_len"] = len(text)
    hf_nodes = soup.find_all(["header", "footer"]) + soup.find_all(
        attrs={"class": re.compile(r"footer|topbar|top-bar|site-header", re.I)})
    hf_text = " \n ".join(n.get_text(" ", strip=True) for n in hf_nodes)[:8000]

    info["emails"] += [(e, "hf") for e in emails_from_text(hf_text)]
    info["emails"] += [(e, "text") for e in emails_from_text(text)]
    for p, labeled in phones_from_text(hf_text, region):
        info["phones"].append((p, "hf"))
    for p, labeled in phones_from_text(text, region):
        info["phones"].append((p, "label" if labeled else "text"))
    info["emails"] = [(e, s) for e, s in info["emails"] if e]
    info["phones"] = [(p, s) for p, s in info["phones"] if p]

    # --- address
    addr = jl["addresses"][0] if jl["addresses"] else ""
    if not addr:
        a_tag = soup.find("address")
        if a_tag:
            s = re.sub(r"\s+", " ", a_tag.get_text(" ", strip=True))
            if 10 <= len(s) <= 220 and re.search(r"\d", s):
                addr = s
    if not addr:
        parts = [(soup.find(attrs={"itemprop": k}) or {}) for k in ("streetAddress", "addressLocality", "addressRegion", "postalCode")]
        vals = [p.get_text(" ", strip=True) for p in parts if p and hasattr(p, "get_text")]
        if len(vals) >= 2:
            addr = ", ".join(vals)
    if not addr:
        m = ADDR_US_RE.search(hf_text) or ADDR_US_RE.search(text)
        addr = m.group(0) if m else ""
    info["address"] = addr

    # --- people (JSON-LD first, then page structure)
    people = []
    for p in jl["people"]:
        f, l = split_name(p["name"])
        if f and l and role_rank(p["role"]) < 99:
            people.append({"first": f, "last": l, "role": p["role"][:70],
                           "email": clean_email(p["email"]), "phone": normalize_phone(p["phone"], region)})
    for f, l, role in people_from_lines(lines, text):
        people.append({"first": f, "last": l, "role": role, "email": "", "phone": ""})
    seen, uniq = set(), []
    for p in people:
        k = (p["first"].lower(), p["last"].lower())
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    uniq.sort(key=lambda p: role_rank(p["role"]))
    for p in uniq[:3]:
        cc = card_contacts(soup, p["first"], p["last"])
        if cc:
            p["card_emails"] = cc.get("emails", [])
            p["card_phones"] = [normalize_phone(x, region) for x in cc.get("phones", [])]
            p["card_linkedin"] = cc.get("linkedin", "")
    info["people"] = uniq

    # --- name (home)
    if kind == "home":
        og = soup.find("meta", property="og:site_name")
        title = soup.title.get_text(strip=True) if soup.title else ""
        info["name"] = (jl["name"] or (og.get("content", "").strip() if og else "")
                        or clean_title(title, norm_domain(url)))
        # --- crawl links
        host = norm_domain(url)
        scored = {}
        for full, label in anchors:
            if norm_domain(full) != host or full.lower().split("?")[0].endswith(SKIP_EXT):
                continue
            blob = (urlparse(full).path + " " + label).lower()
            for rank, hints in LINK_RANKS:
                if any(h in blob for h in hints):
                    key = full.split("?")[0].rstrip("/")
                    scored[key] = min(scored.get(key, 9), rank)
                    break
        base_key = url.split("?")[0].rstrip("/")
        info["links"] = [(u, r) for u, r in sorted(scored.items(), key=lambda x: x[1]) if u != base_key]

    # --- excerpt for the (optional) AI step: only lines that matter
    keep, kws = set(), [k for k in field_kw if k]
    for i, line in enumerate(lines):
        low = line.lower()
        if ROLE_RE.search(line) or any(k in low for k in kws):
            keep.update(x for x in (i - 1, i, i + 1) if 0 <= x < len(lines))
    info["windows"] = "\n".join(lines[i][:200] for i in sorted(keep))[:2500]
    return info


def page_kind(url, base):
    path = urlparse(url).path.lower()
    if path in ("", "/") or url.rstrip("/") == base.rstrip("/"):
        return "home"
    for rank, name in ((0, "contact"), (1, "team"), (2, "about")):
        if any(h in path for h in LINK_RANKS[rank][1]):
            return name
    return "other"


# ---------------------------------------------------------------------------
# Site crawler
# ---------------------------------------------------------------------------
class SiteCrawler:
    def __init__(self, cfg, gemini, fetcher, log, stop):
        self.cfg, self.gemini, self.fetch, self.log, self.stop = cfg, gemini, fetcher, log, stop
        self.region = (cfg.get("region") or "US").upper()
        self.allow_free = bool(cfg.get("allow_freemail", True))
        self.mx_cache = {}

    def mx_ok(self, domain):
        if domain in FREEMAIL or dns_resolver is None:
            return True
        if domain in self.mx_cache:
            return self.mx_cache[domain]
        ok = True
        try:
            res = dns_resolver.Resolver()
            res.lifetime = 4
            try:
                res.resolve(domain, "MX")
            except dns_resolver.NoAnswer:
                res.resolve(domain, "A")
        except (dns_resolver.NXDOMAIN, dns_resolver.NoNameservers):
            ok = False
        except Exception:
            ok = True  # network hiccup - do not discard
        self.mx_cache[domain] = ok
        return ok

    # ---- ownership + scoring ----
    def owner_kind(self, email, site_domains, src, pkind):
        dom = email.rsplit("@", 1)[1]
        if domain_match(dom, site_domains):
            return "domain"
        if self.allow_free and dom in FREEMAIL and (src in ("mailto", "jsonld", "itemprop", "hf", "cf") or pkind == "contact"):
            return "published"
        return None

    def choose_email(self, cands, site_domains):
        agg = {}
        for c in cands:
            e = c["email"]
            kind = self.owner_kind(e, site_domains, c["src"], c["pkind"])
            local = e.split("@")[0]
            if not kind or local in BAD_LOCALS:
                continue
            a = agg.setdefault(e, {"w": 0.0, "pages": set(), "kind": kind})
            a["w"] = max(a["w"], SRC_W.get(c["src"], 1.0))
            a["pages"].add(c["page"])
        ranked = []
        for e, a in agg.items():
            local = e.split("@")[0]
            s = (a["w"] + (3 if a["kind"] == "domain" else 0) + (3 if local in COMPANY_LOCALS else 0)
                 + 1.5 * (len(a["pages"]) - 1))
            ranked.append((s, e, a["kind"]))
        ranked.sort(key=lambda x: (-x[0], x[1]))
        for _, e, kind in ranked[:6]:
            if self.mx_ok(e.rsplit("@", 1)[1]):
                return e, ("company domain + MX" if kind == "domain" else "published on company site")
        return "", ""

    def choose_phone(self, cands):
        agg = {}
        for c in cands:
            a = agg.setdefault(c["phone"], {"w": 0.0, "pages": set(), "src": c["src"]})
            if PHONE_W.get(c["src"], 1) > a["w"]:
                a["w"], a["src"] = PHONE_W.get(c["src"], 1), c["src"]
            a["pages"].add(c["page"])
        best = sorted(((a["w"] + 2.0 * (len(a["pages"]) - 1), p, a["src"]) for p, a in agg.items()),
                      key=lambda x: (-x[0], x[1]))
        if not best:
            return "", ""
        labels = {"tel": "tel: link", "jsonld": "structured data", "itemprop": "structured data",
                  "label": "labelled on page", "hf": "header/footer", "text": "page text", "source": "page source"}
        return best[0][1], "on site: " + labels.get(best[0][2], "page")

    # ---- crawl ----
    def open_home(self, website):
        host = norm_domain(website)
        variants = []
        if re.match(r"^https?://", website, re.I):
            variants.append(root_url(website))
        for v in (f"https://{host}", f"https://www.{host}", f"http://{host}"):
            if v not in variants:
                variants.append(v)
        for v in variants[:4]:
            if self.stop.is_set():
                break
            html, final, status = self.fetch.get_page(v)
            if html:
                return html, final, ""
            if status == "dns" and v.startswith("https://www."):
                return None, None, "domain does not resolve"
            if status == "robots":
                return None, None, "blocked by robots.txt"
        return None, None, "site unreachable"

    def sitemap_links(self, base):
        html, _, st = self.fetch.http_get(base + "/sitemap.xml")
        if not html:
            return []
        host = norm_domain(base)
        out = []
        for loc in re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", html):
            if norm_domain(loc) == host and not loc.lower().endswith((".xml",) + SKIP_EXT):
                if page_kind(loc, base) in ("contact", "team", "about"):
                    out.append(loc)
        return out[:4]

    def crawl(self, website, name_hint="", want_fields=()):
        res = {"ok": False, "reason": "", "website": root_url(website), "name": name_hint or "",
               "email": "", "email_src": "", "phone": "", "phone_src": "", "person": None,
               "socials": {}, "li_company": "", "address": "", "fields": {}, "pages": 0,
               "site_domains": set(), "home_text_len": 0}
        home_html, final, why = self.open_home(website)
        if not home_html:
            res["reason"] = why or "site unreachable"
            return res
        base = root_url(final)
        res["website"] = base
        site_domains = {norm_domain(website), norm_domain(final)} - {""}
        res["site_domains"] = site_domains
        low_head = home_html[:6000].lower()
        if any(h in low_head for h in PARKED_HINTS):
            res["reason"] = "parked / for-sale domain"
            return res

        field_kw = []
        for f in want_fields:
            field_kw += [t for t in re.findall(r"[a-z]{4,}", f.lower()) if t not in ("size", "number", "count", "total", "info")]
        e_cands, p_cands, people, socials, li_people = [], [], [], {}, []
        address, jl_name = "", ""
        windows, visited = [], set()
        pages_done = 0

        def ingest(url, html, kind):
            nonlocal address
            info = analyze_page(html, url, kind, self.region, field_kw)
            for e, s in info["emails"]:
                e_cands.append({"email": e, "src": s, "pkind": kind, "page": url})
            for p, s in info["phones"]:
                p_cands.append({"phone": p, "src": s, "page": url})
            for p in info["people"]:
                p["page"] = url
                people.append(p)
            for k, v in info["socials"].items():
                socials.setdefault(k, v)
            li_people.extend(info["li_people"])
            address = address or info["address"]
            if info["windows"]:
                windows.append(info["windows"])
            return info

        home = ingest(base, home_html, "home")
        visited.add(base.rstrip("/"))
        pages_done = 1
        res["home_text_len"] = home["text_len"]
        if not res["name"]:
            res["name"] = home["name"]

        plan = [u for u, _ in home["links"]]
        kinds = {page_kind(u, base) for u in plan}
        if "contact" not in kinds and "contact" not in " ".join(plan):
            plan = [base + p for p in PROBES_CONTACT[:2]] + plan
        if not ({"team", "about"} & kinds):
            sm = self.sitemap_links(base)
            plan = sm + plan + [base + p for p in PROBES_ABOUT[:2]]
        attempts = 0

        def best_person_ready():
            return any(role_rank(p["role"]) < 99 and (p.get("card_emails") or p.get("email")) for p in people)

        def crawl_list(urls):
            nonlocal pages_done, attempts
            for u in urls:
                if self.stop.is_set() or pages_done >= MAX_PAGES or attempts >= MAX_PAGES + 3:
                    return
                key = u.split("?")[0].rstrip("/")
                if key in visited:
                    continue
                visited.add(key)
                attempts += 1
                sleep_range(PAGE_DELAY, self.stop)
                html, final_u, status = self.fetch.get_page(u)
                if not html or norm_domain(final_u) not in site_domains and not domain_match(norm_domain(final_u), site_domains):
                    continue
                ingest(u, html, page_kind(u, base))
                pages_done += 1
                if (self.choose_email_quick(e_cands, site_domains) and p_cands and best_person_ready()):
                    return

        crawl_list(plan)
        # email still missing -> legal / privacy pages often publish the contact address
        if not self.choose_email_quick(e_cands, site_domains) and not self.stop.is_set():
            crawl_list([base + p for p in PROBES_EMAIL])
        res["pages"] = pages_done

        # ---- company-level contact
        res["email"], res["email_src"] = self.choose_email(e_cands, site_domains)
        res["phone"], res["phone_src"] = self.choose_phone(p_cands)
        res["socials"] = {k: v for k, v in socials.items() if k != "linkedin_company"}
        res["li_company"] = socials.get("linkedin_company", "")
        res["address"] = address

        # ---- decision-maker: structure first, AI second (non-blocking)
        need_ai_people = not any(role_rank(p["role"]) < 99 for p in people)
        custom_fields = [f for f in want_fields]
        if windows and self.gemini.enabled and (need_ai_people or custom_fields):
            excerpt = "\n---\n".join(windows)
            ai = self.gemini.analyze_site(res["name"] or norm_domain(base), excerpt,
                                          need_ai_people, custom_fields)
            for f, l, role in ai["people"]:
                people.append({"first": f, "last": l, "role": role, "email": "", "phone": "", "page": base})
            res["fields"] = ai["fields"]
        ranked = sorted((p for p in people if role_rank(p["role"]) < 99),
                        key=lambda p: (role_rank(p["role"]),
                                       0 if (p.get("card_emails") or p.get("email")) else 1))
        if ranked:
            res["person"] = self.finish_person(ranked[0], e_cands, site_domains, li_people)
        res["ok"] = True
        return res

    def choose_email_quick(self, cands, site_domains):
        for c in cands:
            if self.owner_kind(c["email"], site_domains, c["src"], c["pkind"]) and c["email"].split("@")[0] not in BAD_LOCALS:
                return True
        return False

    def finish_person(self, p, e_cands, site_domains, li_people):
        out = {"first": p["first"], "last": p["last"], "role": p["role"], "direct_email": "",
               "direct_phone": "", "linkedin": ""}
        pats = person_email_patterns(p["first"], p["last"])
        pool = [(p.get("email", ""), "jsonld")] + [(e, "card") for e in p.get("card_emails", [])]
        # card/JSON-LD emails first, then local-part pattern matches among the company's own emails
        for e, src in pool:
            if e and self.owner_kind(e, site_domains, "mailto", "other") and e.split("@")[0] not in BAD_LOCALS \
                    and self.mx_ok(e.rsplit("@", 1)[1]):
                if src == "jsonld" or len(p.get("card_emails", [])) == 1 or e.split("@")[0] in pats:
                    out["direct_email"] = e
                    break
        if not out["direct_email"] and pats:
            for c in e_cands:
                e = c["email"]
                if e.split("@")[0] in pats and domain_match(e.rsplit("@", 1)[1], site_domains) \
                        and self.mx_ok(e.rsplit("@", 1)[1]):
                    out["direct_email"] = e
                    break
        phones = [x for x in ([p.get("phone", "")] + p.get("card_phones", [])) if x]
        if len(set(phones)) == 1:
            out["direct_phone"] = phones[0]
        li = p.get("card_linkedin", "")
        c = classify_social(li) if li else None
        if c and c[0] == "linkedin_person":
            out["linkedin"] = c[1]
        else:
            fl = (re.sub(r"[^a-z]", "", ascii_fold(p["first"]).lower()), re.sub(r"[^a-z]", "", ascii_fold(p["last"].split()[-1]).lower()))
            for u in li_people:
                slug = re.sub(r"[^a-z]", "", u.rsplit("/", 1)[-1].lower())
                if len(fl[0]) >= 2 and len(fl[1]) >= 2 and fl[0] in slug and fl[1] in slug:
                    out["linkedin"] = u
                    break
        return out


# ---------------------------------------------------------------------------
# Excel / CSV export
# ---------------------------------------------------------------------------
def _csv_safe(v):
    v = str(v or "")
    return "'" + v if v[:1] in ("=", "@") else v


def write_csv(rows, columns, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow([c[1] for c in columns])
        for r in rows:
            w.writerow([_csv_safe(r.get(c[0], "")) for c in columns])


def link_label(key, url, rec):
    if key == "website":
        return norm_domain(url) or url
    if key == "linkedin":
        return rec.get("linkedin_label") or "LinkedIn"
    return dict((c[0], c[1]) for c in SOCIAL_COLUMNS).get(key, "Link")


def export_xlsx(rows, columns, path):
    # social columns that are empty for every lead are dropped to keep the sheet clean
    cols = [c for c in columns if not (c in SOCIAL_COLUMNS and not any(r.get(c[0]) for r in rows))]
    wb = Workbook()
    ws = wb.active
    ws.title = "Leads"
    ws.append([c[1] for c in cols])
    navy = PatternFill("solid", fgColor="1F4E78")
    band = PatternFill("solid", fgColor="F2F6FA")
    thin = Side(style="thin", color="D9D9D9")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    link_font = Font(name="Calibri", size=11, color="0563C1", underline="single")
    for cell in ws[1]:
        cell.fill = navy
        cell.font = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border
    widths = [len(c[1]) for c in cols]
    for ri, r in enumerate(rows, start=2):
        for ci, (key, _, kind) in enumerate(cols, start=1):
            val = str(r.get(key, "") or "")
            cell = ws.cell(row=ri, column=ci)
            shown = val
            if val and kind == "url":
                shown = link_label(key, val, r)
                cell.value = shown
                cell.hyperlink = val          # real clickable hyperlink
                cell.font = link_font
            elif val and kind == "email":
                cell.value = val                  # plain black text, deliberately NOT a hyperlink
                cell.font = Font(name="Calibri", size=11, color="000000")
            else:
                cell.value = val
                if val.startswith("="):
                    cell.data_type = "s"      # never let scraped text become a formula
            cell.alignment = Alignment(vertical="center")
            cell.border = border
            if ri % 2 == 1:
                cell.fill = band
            widths[ci - 1] = max(widths[ci - 1], min(len(shown), 60))
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = min(w + 3, 60)
    ws.row_dimensions[1].height = 24
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = ws.dimensions
    wb.save(path)


# ---------------------------------------------------------------------------
# Input readers for Mode B
# ---------------------------------------------------------------------------
URL_IN_TEXT = re.compile(r"(?:https?://)?(?:www\.)?[a-z0-9\-]+(?:\.[a-z0-9\-]+)*\.[a-z]{2,}(?:/\S*)?", re.I)


def rows_from_table(table):
    table = [[str(c or "").strip() for c in r] for r in table if any(str(c or "").strip() for c in r)]
    if not table:
        return []
    header = [h.lower() for h in table[0]]
    colmap = {}
    for idx, h in enumerate(header):
        for key, aliases in HEADER_ALIASES.items():
            if h in aliases and key not in colmap.values():
                colmap[idx] = key
                break
    rows = []
    if colmap:
        for r in table[1:]:
            rows.append({key: (r[idx] if idx < len(r) else "") for idx, key in colmap.items()})
    else:  # headerless: find a URL cell and a name cell
        for r in table:
            row = {}
            for c in r:
                if not row.get("website") and URL_IN_TEXT.fullmatch(c) and "@" not in c:
                    row["website"] = c
                elif c and not row.get("business_name"):
                    row["business_name"] = c
            rows.append(row)
    return [r for r in rows if r.get("website") or r.get("business_name")]


def read_input_file(path):
    ext = Path(path).suffix.lower()
    if ext in (".xlsx", ".xlsm"):
        wb = load_workbook(path, read_only=True, data_only=True)
        table = [list(r) for r in wb.active.iter_rows(values_only=True)]
    else:
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            sample = f.read(4096)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
            except csv.Error:
                dialect = csv.excel
            table = list(csv.reader(f, dialect))
    return rows_from_table(table)


def rows_from_pasted(text):
    lines = [l for l in text.splitlines() if l.strip()]
    if not lines:
        return []
    if any("\t" in l for l in lines[:3]):
        return rows_from_table([l.split("\t") for l in lines])
    rows = []
    for line in lines:
        no_email = re.sub(r"\S+@\S+", " ", line)
        m = URL_IN_TEXT.search(no_email)
        website = m.group(0).rstrip(".,;)") if m else ""
        name = no_email.replace(m.group(0), " ") if m else no_email
        name = re.sub(r"^[\s\-\u2013|,:;\u2022*\d.)]+|[\s\-\u2013|,:;]+$", "", name)
        name = re.sub(r"\s{2,}", " ", name).strip(" -|,:;")
        if website or name:
            rows.append({"business_name": name, "website": website})
    return rows


def name_matches_site(name, domain, text_hint):
    stop = {"the", "inc", "llc", "ltd", "co", "company", "group", "services", "service", "and", "corp", "of"}
    toks = [t for t in norm_name(name).split() if len(t) >= 3 and t not in stop]
    if not toks:
        return True
    dom = domain.replace("-", "").replace(".", "")
    if any(t in dom for t in toks):
        return True
    low = (text_hint or "").lower()
    return sum(t in low for t in toks) >= max(1, (len(toks) + 1) // 2)


def build_columns(custom):
    return (list(CORE_COLUMNS) + [(k, h, "text") for k, h in custom]
            + list(SOCIAL_COLUMNS) + list(TAIL_COLUMNS))


def short_prompt(text, fallback="leads"):
    s = re.sub(r"[^A-Za-z0-9]+", "_", ascii_fold(text or "")).strip("_")[:40].strip("_")
    return s or fallback


def read_checkpoint(path):
    """Crash-proof JSONL log -> (leads, done_keys, rejected). A torn last line (power cut) is ignored."""
    leads, done, rej, seen = [], set(), [], set()
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                try:
                    o = json.loads(line)
                except Exception:
                    continue
                t = o.pop("t", "")
                if t == "lead":
                    dom = norm_domain(o.get("website", ""))
                    if dom and dom in seen:
                        continue
                    seen.add(dom)
                    o["_order"] = len(leads)
                    leads.append(o)
                elif t == "done":
                    done.add(o.get("k", ""))
                elif t == "rej":
                    rej.append(o)
    except FileNotFoundError:
        pass
    return leads, done, rej


# ---------------------------------------------------------------------------
# Engine (worker threads)
# ---------------------------------------------------------------------------
class Engine:
    def __init__(self, cfg, history, ui, stop_event):
        self.cfg, self.history, self.ui, self.stop = cfg, history, ui, stop_event
        self.log = ui.log
        key = cfg.get("gemini_key") or os.environ.get("GEMINI_API_KEY", "")
        self.gemini = Gemini(key, cfg.get("model"), cfg.get("gemini_rpm", DEFAULT_GEMINI_RPM), self.log, stop_event)
        self.search = SearchGate(self.log, stop_event)
        self.renderer = JSRenderer(self.log, stop_event)
        self.fetcher = Fetcher(cfg, self.renderer, self.log, stop_event)
        self.crawler = SiteCrawler(cfg, self.gemini, self.fetcher, self.log, stop_event)
        self.workers = max(1, min(32, int(cfg.get("workers") or DEFAULT_WORKERS)))
        self.results, self.rejected = [], []
        self.custom = []             # [(key, header)]
        self.columns = list(CORE_COLUMNS) + list(SOCIAL_COLUMNS) + list(TAIL_COLUMNS)
        self.target = 10 ** 9
        self.prompt, self.finished_ok, self.sites_done = "", False, 0
        self.lock = threading.Lock()
        self.save_lock = threading.Lock()
        self.net_lock = threading.Lock()
        self.stats = {"kept": 0, "dupes": 0, "rejected": 0, "direct": 0, "named": 0, "company": 0,
                      "ai_calls": 0, "ai_skipped": 0}
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.ts = ts
        self.mode, self.sig, self.short = "A", "", "leads"
        self.ckpt_path = DATA_DIR / f"checkpoint_{ts}.jsonl"
        self.final_path = OUT_DIR / f"leads_{ts}_FULL.xlsx"
        self.reject_path = OUT_DIR / f"rejected_{ts}.csv"
        self.ckpt_lock = threading.Lock()
        self.result_domains, self.done_keys = set(), set()

    # ---- columns ----
    def set_custom_columns(self, names):
        self.custom = split_requested_columns(names)
        self.columns = build_columns(self.custom)

    @property
    def custom_field_names(self):
        return [h for k, h in self.custom if k != "address"]

    # ---- results ----
    def count(self):
        with self.lock:
            return len(self.results)

    def snapshot(self):
        with self.lock:
            return sorted(self.results, key=lambda r: r.get("_order", 0))

    def _push_stats(self):
        s = dict(self.stats)
        s["ai_calls"], s["ai_skipped"] = self.gemini.stats["calls"], self.gemini.stats["skipped"]
        self.ui.set_stats(s)

    def _ckpt(self, obj):
        """Append one record to the crash-proof log and force it to disk (survives power loss)."""
        try:
            line = json.dumps(obj, ensure_ascii=False)
            with self.ckpt_lock:
                with open(self.ckpt_path, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
                    f.flush()
                    os.fsync(f.fileno())
        except Exception as e:
            self.log(f"Checkpoint write failed: {e}")

    def _mark_done(self, key):
        self.done_keys.add(key)
        self._ckpt({"t": "done", "k": key})

    def _reject(self, name, website, reason, email="", phone=""):
        item = {"business": name, "website": website, "reason": reason,
                "email_found": email, "phone_found": phone}
        with self.lock:
            self.rejected.append(item)
            self.stats["rejected"] += 1
        self._ckpt({"t": "rej", **item})
        self._push_stats()

    def _keep(self, rec):
        dom = norm_domain(rec.get("website", ""))
        with self.lock:
            if len(self.results) >= self.target or (dom and dom in self.result_domains):
                return False
            if dom:
                self.result_domains.add(dom)
            rec["_order"] = len(self.results)
            self.results.append(rec)
            n = len(self.results)
            lvl = rec.get("contact_level", "")
            self.stats["kept"] = n
            if "direct" in lvl:
                self.stats["direct"] += 1
            elif lvl.startswith("Decision-maker") or lvl == "Provided contact":
                self.stats["named"] += 1
            else:
                self.stats["company"] += 1
        self._ckpt({"t": "lead", **rec})           # every single lead is on disk before we continue
        self._push_stats()
        if n % MICRO_SAVE == 0:
            try:
                self.history.save()
            except Exception:
                pass
        if n % XLSX_BATCH == 0:
            self._write_batch(n - XLSX_BATCH, n)
            self.log(f"--- Batch {n - XLSX_BATCH + 1}-{n} saved to Excel ---")
        return True

    def _write_batch(self, lo, hi):
        """Formatted .xlsx for leads lo+1 .. hi, named <prompt>_<lo+1>_<hi>.xlsx"""
        try:
            rows = [r for r in self.snapshot() if lo <= r.get("_order", 0) < hi]
            if not rows:
                return
            path = OUT_DIR / f"{self.short}_{lo + 1}_{hi}.xlsx"
            with self.save_lock:
                export_xlsx(rows, self.columns, path)
                if hi - lo == XLSX_BATCH:             # drop an older partial tail such as <prompt>_51_81.xlsx
                    for old in OUT_DIR.glob(f"{self.short}_{lo + 1}_*.xlsx"):
                        if old != path:
                            try:
                                old.unlink()
                            except OSError:
                                pass
        except Exception as e:
            self.log(f"Batch Excel save failed: {e}")

    def _finalize(self):
        rows = self.snapshot()
        try:
            self.history.save()
        except Exception as e:
            self.log(f"History save failed: {e}")
        if rows:
            try:
                with self.save_lock:
                    export_xlsx(rows, self.columns, self.final_path)
                self.log(f"FULL Excel report ({len(rows)} leads): {self.final_path}")
            except Exception as e:
                self.log(f"Excel export failed: {e}")
            tail_lo = (len(rows) // XLSX_BATCH) * XLSX_BATCH
            if len(rows) > tail_lo:
                self._write_batch(tail_lo, len(rows))      # last partial batch, e.g. _101_112
        if self.rejected:
            try:
                with open(self.reject_path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.DictWriter(f, fieldnames=["business", "website", "reason", "email_found", "phone_found"])
                    w.writeheader()
                    w.writerows(self.rejected)
                self.log(f"Rejected leads (with reasons): {self.reject_path}")
            except Exception as e:
                self.log(f"Could not write rejected list: {e}")
        self.log(f"Done. {len(rows)} complete leads | {len(self.rejected)} discarded (missing email/phone/invalid) | "
                 f"AI calls: {self.gemini.stats['calls']} (skipped to avoid waiting: {self.gemini.stats['skipped']}) | "
                 f"history: {len(self.history)}")

    def _close(self):
        try:
            self.renderer.close()
        except Exception:
            pass

    # ---- connectivity / session helpers ----
    def net_ok(self):
        for url in ("https://www.gstatic.com/generate_204", "https://www.cloudflare.com/cdn-cgi/trace"):
            try:
                requests.get(url, timeout=5)
                return True
            except Exception:
                continue
        return False

    def wait_online(self, max_wait=900):
        with self.net_lock:                     # one worker waits, the rest queue behind it
            if self.net_ok():
                return True
            self.log("Internet connection lost - pausing, will resume automatically ...")
            self.ui.set_status("Offline - waiting for connection ...")
            end = time.time() + max_wait
            while time.time() < end and not self.stop.is_set():
                sleep_stop(10, self.stop)
                if self.net_ok():
                    self.log("Connection restored - continuing.")
                    return True
            return False

    def _session_write(self, finished):
        try:
            save_json_atomic(SESSION_FILE, {
                "mode": self.mode, "sig": self.sig, "prompt": self.prompt, "short": self.short,
                "finished": bool(finished), "target": self.target if self.target < 10 ** 8 else 0,
                "ckpt": str(self.ckpt_path), "final": str(self.final_path), "reject": str(self.reject_path),
                "custom": [list(c) for c in self.custom],
                "updated": datetime.now().isoformat(timespec="seconds")})
        except Exception as e:
            self.log(f"Could not write session file: {e}")

    def _begin_session(self, mode, sig, prompt, short):
        """Resume an identical unfinished run from its checkpoint, otherwise start fresh. -> resumed(bool)"""
        self.mode, self.sig, self.prompt = mode, sig, prompt
        sess = load_json(SESSION_FILE, {})
        if (self.cfg.get("resume", True) and sess.get("mode") == mode and sess.get("sig") == sig
                and not sess.get("finished") and Path(sess.get("ckpt", "")).exists()):
            leads, done, rej = read_checkpoint(sess["ckpt"])
            self.ckpt_path = Path(sess["ckpt"])
            self.final_path = Path(sess.get("final") or self.final_path)
            self.reject_path = Path(sess.get("reject") or self.reject_path)
            self.short = sess.get("short") or short
            if sess.get("custom"):
                self.set_custom_columns([c[1] for c in sess["custom"]])
            self.results, self.rejected, self.done_keys = leads, rej, set(done)
            self.result_domains = {norm_domain(r.get("website", "")) for r in leads}
            self.stats.update({"kept": len(leads), "rejected": len(rej)})
            for r in leads:
                self.history.add(norm_domain(r.get("website", "")), {"resumed": True})
            for k in done:
                self.history.add(k, {"resumed": True})
            self.log(f"RESUMING previous run: {len(leads)} complete leads restored, {len(done)} sites already processed. "
                     f"Continuing from lead #{len(leads) + 1}.")
            self._push_stats()
            return True
        self.short = short
        if any(OUT_DIR.glob(f"{short}_*.xlsx")):      # never overwrite files of an older run
            self.short = f"{short}_{datetime.now():%m%d_%H%M}"
        self.final_path = OUT_DIR / f"{self.short}_FULL_{self.ts}.xlsx"
        return False

    # ---- directory fallback (phone only; needs two independent sources) ----
    def directory_phone(self, name, domain, location):
        if not (name and self.cfg.get("directory_fallback", True)) or DDGS is None:
            return ""
        hits = self.search.search(f'"{name}" {location} phone number'.strip(), 8) or []
        votes, target = {}, norm_name(name)
        for h in hits:
            host = norm_domain(h.get("href") or h.get("url") or "")
            if not host or host == domain:
                continue
            blob = (h.get("title", "") + " " + h.get("body", ""))
            if target not in norm_name(blob):
                continue
            for p, _ in phones_from_text(blob, self.crawler.region):
                votes.setdefault(p, set()).add(host)
        for p, hosts in sorted(votes.items(), key=lambda x: -len(x[1])):
            if len(hosts) >= 2:
                return p
        return ""

    # ---- record assembly ----
    def compose(self, crawl, row=None):
        row = row or {}
        rec = {k: "" for k in BASE_KEYS}
        rec["website"] = row.get("website") or crawl["website"]
        rec["business_name"] = row.get("business_name") or crawl["name"] or norm_domain(crawl["website"])
        email, email_src = crawl["email"], crawl["email_src"]
        phone, phone_src = crawl["phone"], crawl["phone_src"]
        p = crawl.get("person")
        if p:
            rec["first_name"], rec["last_name"], rec["role"] = p["first"], p["last"], p["role"]
            level = "Decision-maker + company contact"
            if p.get("direct_email"):
                email, email_src = p["direct_email"], "personal address on company domain"
                level = "Decision-maker (direct email)"
            if p.get("direct_phone"):
                phone, phone_src = p["direct_phone"], "listed next to the person"
                level = "Decision-maker (direct email + phone)" if p.get("direct_email") else "Decision-maker (direct phone)"
            rec["linkedin"], rec["linkedin_label"] = (p["linkedin"], "LinkedIn (person)") if p.get("linkedin") else ("", "")
        else:
            rec["first_name"], rec["last_name"], rec["role"] = "Management", "Team", "Management / Team"
            level = "Company contact (no individual found)"
        if not rec["linkedin"] and crawl.get("li_company"):
            rec["linkedin"], rec["linkedin_label"] = crawl["li_company"], "LinkedIn (company)"
        # user-provided values (Mode B) win when valid
        notes = []
        pe = clean_email(row.get("email", ""))
        if pe:
            email, email_src = pe, "provided by you"
        pp = normalize_phone(row.get("phone", ""), self.crawler.region) if row.get("phone") else ""
        if pp:
            phone, phone_src = pp, "provided by you"
        if row.get("first_name") or row.get("last_name"):
            rec["first_name"], rec["last_name"] = row.get("first_name", ""), row.get("last_name", "")
            rec["role"] = row.get("role") or rec["role"]
            level = "Provided contact"
        elif row.get("role") and p:
            rec["role"] = row["role"]
        if row.get("linkedin"):
            rec["linkedin"], rec["linkedin_label"] = row["linkedin"], "LinkedIn"
        rec["email"], rec["phone"] = email, phone
        for k in ("facebook", "instagram", "twitter", "youtube", "tiktok"):
            rec[k] = crawl["socials"].get(k, "")
        rec["address"] = crawl.get("address", "")
        for key, header in self.custom:
            if key == "address":
                continue
            rec[key] = ""
            for fk, fv in crawl.get("fields", {}).items():
                if slugify(fk) == key[3:] or slugify(fk) == slugify(header):
                    rec[key] = fv
        rec["contact_level"] = level
        rec["verification"] = f"Email: {email_src or '-'} | Phone: {phone_src or '-'}"
        return rec

    def validate(self, rec):
        if not rec["email"] and not rec["phone"]:
            return "no email and no phone found"
        if not rec["email"]:
            return "no valid company email found"
        if not rec["phone"]:
            return "no valid phone found"
        if clean_email(rec["email"]) != rec["email"]:
            return "email failed validation"
        return ""

    # ---- one company, end to end ----
    def process_site(self, website, name_hint="", row=None, location="", discovered=False):
        domain = norm_domain(website)
        label = name_hint or domain
        if self.stop.is_set():
            return
        crawl = self.crawler.crawl(website, name_hint=name_hint, want_fields=self.custom_field_names)
        meta = {"name": crawl["name"] or name_hint, "date": datetime.now().strftime("%Y-%m-%d")}
        if not crawl["ok"] and crawl["reason"] == "site unreachable" and not self.stop.is_set() and not self.net_ok():
            if not self.wait_online():
                return {"offline": True}      # not the site's fault - do NOT record it as seen
            crawl = self.crawler.crawl(website, name_hint=name_hint, want_fields=self.custom_field_names)
        if self.stop.is_set() and not (crawl.get("email") and crawl.get("phone")):
            return {"aborted": True}          # interrupted mid-crawl - leave it for the next run
        if not crawl["ok"]:
            self.log(f"   x {label}: {crawl['reason']}")
            self._reject(label, website, crawl["reason"])
            return
        if discovered and name_hint and not name_matches_site(name_hint, domain, crawl["name"]):
            self.log(f"   x {label}: website does not appear to belong to this company")
            self._reject(label, website, "website/company name mismatch")
            return
        if crawl["email"] and not crawl["phone"] and not self.stop.is_set():
            ph = self.directory_phone(crawl["name"] or name_hint or domain, domain, location)
            if ph:
                crawl["phone"], crawl["phone_src"] = ph, "2 independent directory listings"
        rec = self.compose(crawl, row)
        why = self.validate(rec)
        if why:
            self.log(f"   x {rec['business_name']}: discarded - {why}")
            self._reject(rec["business_name"], rec["website"], why, rec["email"], rec["phone"])
            return
        if self._keep(rec):
            tag = {"Decision-maker (direct email + phone)": "DM direct", "Decision-maker (direct email)": "DM email"}.get(
                rec["contact_level"], "DM" if rec["contact_level"].startswith("Decision") else "company")
            self.log(f"   + [{tag}] {rec['business_name']}: {rec['email']} | {rec['phone']}"
                     + (f" | {rec['first_name']} {rec['last_name']} ({rec['role']})" if tag != "company" else ""))
        return meta

    # ---------------- Mode A ----------------
    def run_search(self, prompt):
        try:
            self.ui.set_status("Parsing request ...")
            parsed = self.gemini.parse_prompt(prompt) if self.gemini.enabled else None
            if not parsed:
                parsed = regex_parse_prompt(prompt)
                self.log("Prompt parsed with built-in parser" + ("" if self.gemini.enabled else " (no Gemini key)."))
            niche, location = parsed["niche"], parsed["location"]
            self.target = max(1, int(parsed["count"]))
            if not niche:
                self.log("Could not detect a niche. Example: '200 dental clinics in Chicago'.")
                self.ui.notify("Could not detect a niche in your prompt.")
                return
            extra = list(parsed.get("columns") or []) + [c.strip() for c in str(self.cfg.get("extra_columns", "")).split(",") if c.strip()]
            self.set_custom_columns(extra)
            resumed = self._begin_session("A", prompt, prompt, short_prompt(prompt))
            self.target = max(1, int(parsed["count"]))
            self._session_write(False)
            self.log(f"Target: {self.target} x '{niche}' in '{location or 'anywhere'}' | workers: {self.workers}")
            self.log("Columns: " + ", ".join(c[1] for c in self.columns))
            expansion = {"niche_synonyms": [], "areas": []}
            if self.gemini.enabled:
                self.ui.set_status("Planning search variations ...")
                expansion = self.gemini.suggest_expansion(niche, location)
            queries = self._build_queries(niche, location, expansion)
            self.log(f"{len(queries)} search variations planned.")

            session_keys = set()
            sem = threading.BoundedSemaphore(self.workers * 2)
            ex = ThreadPoolExecutor(max_workers=self.workers)
            try:
                qq, retried = deque(queries), {}
                while qq:
                    q = qq.popleft()
                    if self.stop.is_set() or self.count() >= self.target:
                        break
                    if self.history.query_exhausted(q):
                        continue
                    self.ui.set_status(f"Searching: {q}")
                    self.log(f"SEARCH: {q}")
                    hits = self.search.search(q, 40)
                    if hits is None:               # search failed/blocked - never count as "exhausted"
                        if self.search.blocked_out or self.stop.is_set():
                            self.log("Search engine is refusing this connection. Progress is saved - run again "
                                     "later with the SAME prompt to resume where you stopped.")
                            break
                        if retried.get(q, 0) < 1:
                            retried[q] = 1
                            qq.append(q)
                        continue
                    submitted = 0
                    for hit in hits:
                        if self.stop.is_set() or self.count() >= self.target:
                            break
                        url, title = hit.get("href") or hit.get("url") or "", hit.get("title", "")
                        if not acceptable_hit(url, title):
                            continue
                        domain = norm_domain(url)
                        if domain in session_keys or self.history.seen(domain):
                            self.stats["dupes"] += 1
                            continue
                        got = False
                        while not self.stop.is_set() and self.count() < self.target:
                            if sem.acquire(timeout=0.5):
                                got = True
                                break
                        if not got:
                            break
                        session_keys.add(domain)
                        submitted += 1
                        fut = ex.submit(self._site_task, root_url(url), domain, niche, location)
                        fut.add_done_callback(lambda f: sem.release())
                    if submitted == 0:
                        self.history.mark_exhausted(q)
                    self.ui.set_status(f"Crawling ... {self.count()}/{self.target} leads")
                if not self.stop.is_set() and self.count() < self.target and not self.search.blocked_out:
                    ex.shutdown(wait=True)       # let in-flight sites finish before judging
                    if self.count() < self.target:
                        msg = (f"Search area exhausted: {self.count()} of {self.target} complete leads found "
                               "(leads missing email or phone are discarded by design). Try a nearby location, "
                               "a broader niche, or add a Gemini key for more variations.")
                        self.log(msg)
                        self.ui.notify(msg)
            finally:
                ex.shutdown(wait=True, cancel_futures=bool(self.stop.is_set() or self.count() >= self.target))
                self.finished_ok = self.count() >= self.target or (not self.stop.is_set() and not self.search.blocked_out)
        finally:
            self._session_write(self.finished_ok)
            self._close()
            self._finalize()

    def _site_task(self, website, domain, niche, location):
        try:
            if self.stop.is_set() or self.count() >= self.target:
                return
            self.ui.set_status(f"Crawling {domain} ({self.count()}/{self.target})")
            self.log(f"VISIT: {domain}")
            meta = self.process_site(website, location=location) or {}
            if not (self.stop.is_set() or meta.get("offline") or meta.get("aborted")):
                self.history.add(domain, {"name": meta.get("name", ""), "niche": niche, "location": location,
                                          "date": datetime.now().strftime("%Y-%m-%d")})
                self._mark_done(domain)
                self._tick_history()
        except Exception as e:
            self.log(f"   error on {domain}: {str(e)[:120]}")
        finally:
            self.ui.set_progress(self.count(), self.target)

    def _tick_history(self):
        with self.lock:
            self.sites_done += 1
            due = self.sites_done % HISTORY_SAVE_EVERY == 0
        if due:
            try:
                self.history.save()
            except Exception:
                pass

    @staticmethod
    def _build_queries(niche, location, expansion):
        niches = [niche] + [s for s in expansion.get("niche_synonyms", []) if s.lower() != niche.lower()]
        places = ([location] + expansion.get("areas", [])) if location else (expansion.get("areas", []) or [""])
        templates = ["{n} in {p}", "{n} {p} contact email", "best {n} {p}", "{n} {p} owner",
                     "independent {n} {p}", "{n} near {p} official website"]
        queries, seen = [], set()
        for n in niches:
            for p in places:
                for t in (templates if p == location else templates[:2]):
                    q = re.sub(r"\s+", " ", t.format(n=n, p=p)).strip()
                    if q.lower() not in seen:
                        seen.add(q.lower())
                        queries.append(q)
        return queries

    # ---------------- Mode B ----------------
    def run_enrich(self, rows, skip_history):
        try:
            self.target = 10 ** 9
            import hashlib
            sig = hashlib.sha1("\n".join(sorted(f"{r.get('business_name','')}|{r.get('website','')}" for r in rows)).encode("utf-8", "ignore")).hexdigest()
            self.set_custom_columns([c.strip() for c in str(self.cfg.get("extra_columns", "")).split(",") if c.strip()])
            self._begin_session("B", sig, f"{len(rows)} uploaded rows", "bulk_upload")
            self._session_write(False)
            total = len(rows)
            self.log(f"Loaded {total} rows for enrichment | workers: {self.workers}")
            seen_in_file, todo = set(), []
            for i, row in enumerate(rows, start=1):
                domain = norm_domain(row.get("website", ""))
                key = domain or ("name:" + norm_name(row.get("business_name", "")))
                if key in seen_in_file or key in self.done_keys or (skip_history and self.history.seen(key)):
                    self.stats["dupes"] += 1
                    continue
                seen_in_file.add(key)
                todo.append((i, row, key))
            done = 0
            with ThreadPoolExecutor(max_workers=self.workers) as ex:
                futs = [ex.submit(self._row_task, i, row, key, total) for i, row, key in todo]
                for f in as_completed(futs):
                    done += 1
                    self.ui.set_progress(done, max(len(todo), 1))
                    self.ui.set_status(f"Enriched {done}/{len(todo)}")
                    if self.stop.is_set():
                        for g in futs:
                            g.cancel()
        finally:
            self._session_write(not self.stop.is_set())
            self._close()
            self._finalize()

    def _row_task(self, i, row, key, total):
        try:
            if self.stop.is_set():
                return
            name, website, discovered = row.get("business_name", ""), row.get("website", ""), False
            self.log(f"[{i}/{total}] {name or website}")
            if not website and name:
                for hit in (self.search.search(f"{name} official website", 6) or []):
                    u = hit.get("href") or hit.get("url") or ""
                    if acceptable_hit(u, hit.get("title", "")):
                        website, discovered = root_url(u), True
                        break
            if not website:
                self._reject(name, "", "no website found")
                self.log("   x no website found")
                return
            meta = self.process_site(website, name_hint=name, row=row, discovered=discovered) or {}
            if not (self.stop.is_set() or meta.get("offline") or meta.get("aborted")):
                self.history.add(key, {"name": meta.get("name", name), "source": "upload",
                                       "date": datetime.now().strftime("%Y-%m-%d")})
                self._mark_done(key)
                self._tick_history()
        except Exception as e:
            self.log(f"   error: {str(e)[:120]}")


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------
TAB_A = "Mode A: Niche Search"
TAB_B = "Mode B: Bulk Upload"

_AppBase = ctk.CTk if ctk is not None else object


class App(_AppBase):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.title("Reshalat Lead Finder")
        self.geometry("1040x860")
        self.minsize(920, 740)

        self.cfg = {"gemini_key": "", "model": "auto", "region": "US", "respect_robots": True,
                    "skip_history_b": False, "workers": DEFAULT_WORKERS, "gemini_rpm": DEFAULT_GEMINI_RPM,
                    "extra_columns": "", "resume": True, "allow_freemail": True, "directory_fallback": True, "use_js": True}
        self.cfg.update(load_json(CONFIG_FILE, {}))
        if str(self.cfg.get("model", "")).lower().startswith(DEAD_MODEL_PREFIXES) or not self.cfg.get("model"):
            self.cfg["model"] = "auto"           # old config files saved the retired gemini-2.5-flash
        self.history = History(HISTORY_FILE)
        self.msg_q = queue.Queue()
        self.stop_event = threading.Event()
        self.engine = None
        self.worker = None
        self.input_path = ""
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(100, self._poll)
        self._check_unfinished()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        box = ctk.CTkFrame(self)
        box.grid(row=0, column=0, padx=14, pady=(14, 6), sticky="ew")
        box.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(box, text="Gemini API key (free):").grid(row=0, column=0, padx=8, pady=6, sticky="w")
        self.key_entry = ctk.CTkEntry(box, show="*", placeholder_text="optional - names/roles & custom fields")
        self.key_entry.grid(row=0, column=1, padx=8, pady=6, sticky="ew")
        if self.cfg["gemini_key"]:
            self.key_entry.insert(0, self.cfg["gemini_key"])
        ctk.CTkLabel(box, text="Model:").grid(row=0, column=2, padx=(8, 2))
        self.model_entry = ctk.CTkEntry(box, width=170)
        self.model_entry.grid(row=0, column=3, padx=4)
        self.model_entry.insert(0, self.cfg["model"])
        ctk.CTkLabel(box, text="Phone region:").grid(row=0, column=4, padx=(10, 2))
        self.region_entry = ctk.CTkEntry(box, width=50)
        self.region_entry.grid(row=0, column=5, padx=(2, 8))
        self.region_entry.insert(0, self.cfg["region"])

        ctk.CTkLabel(box, text="Extra columns:").grid(row=1, column=0, padx=8, pady=6, sticky="w")
        self.extra_entry = ctk.CTkEntry(box, placeholder_text="e.g. Address, Employee Size, Revenue (comma-separated)")
        self.extra_entry.grid(row=1, column=1, padx=8, pady=6, sticky="ew")
        self.extra_entry.insert(0, self.cfg.get("extra_columns", ""))
        ctk.CTkLabel(box, text="Parallel sites:").grid(row=1, column=2, padx=(8, 2))
        self.workers_entry = ctk.CTkEntry(box, width=60)
        self.workers_entry.grid(row=1, column=3, padx=4, sticky="w")
        self.workers_entry.insert(0, str(self.cfg["workers"]))
        ctk.CTkLabel(box, text="Gemini calls/min:").grid(row=1, column=4, padx=(10, 2))
        self.rpm_entry = ctk.CTkEntry(box, width=50)
        self.rpm_entry.grid(row=1, column=5, padx=(2, 8))
        self.rpm_entry.insert(0, str(self.cfg["gemini_rpm"]))

        self.var_robots = ctk.BooleanVar(value=self.cfg["respect_robots"])
        self.var_free = ctk.BooleanVar(value=self.cfg["allow_freemail"])
        self.var_dir = ctk.BooleanVar(value=self.cfg["directory_fallback"])
        self.var_resume = ctk.BooleanVar(value=self.cfg["resume"])
        ctk.CTkCheckBox(box, text="Respect robots.txt", variable=self.var_robots).grid(
            row=2, column=0, padx=8, pady=6, sticky="w")
        ctk.CTkCheckBox(box, text="Accept gmail/yahoo-type emails the company publishes itself",
                        variable=self.var_free).grid(row=2, column=1, padx=8, pady=6, sticky="w")
        ctk.CTkCheckBox(box, text="Directory phone fallback", variable=self.var_dir).grid(
            row=2, column=2, columnspan=3, padx=8, pady=6, sticky="w")
        ctk.CTkCheckBox(box, text="Resume unfinished run if the prompt is identical", variable=self.var_resume).grid(
            row=3, column=0, columnspan=3, padx=8, pady=6, sticky="w")
        ctk.CTkLabel(box, text="Strict mode: email AND phone required", text_color="#7FB3FF").grid(
            row=2, column=5, padx=8, sticky="e")

        self.tabs = ctk.CTkTabview(self, height=190)
        self.tabs.grid(row=1, column=0, padx=14, pady=6, sticky="ew")
        ta, tb = self.tabs.add(TAB_A), self.tabs.add(TAB_B)
        ta.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(ta, anchor="w", text="Describe your target (niche, location, count, optional extra fields). "
                                          "Example: 500 dental clinics in Chicago with address and employee size"
                     ).grid(row=0, column=0, sticky="ew")
        self.prompt_box = ctk.CTkTextbox(ta, height=110)
        self.prompt_box.grid(row=1, column=0, sticky="ew", pady=4)

        tb.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(tb, text="Choose CSV / Excel ...", width=170, command=self._choose_file).grid(
            row=0, column=0, padx=4, pady=4)
        self.file_label = ctk.CTkLabel(tb, text="No file selected", anchor="w")
        self.file_label.grid(row=0, column=1, sticky="ew", padx=6)
        self.var_skip_hist = ctk.BooleanVar(value=self.cfg["skip_history_b"])
        ctk.CTkCheckBox(tb, text="Skip companies already in history", variable=self.var_skip_hist).grid(
            row=0, column=2, padx=6)
        ctk.CTkLabel(tb, anchor="w", text="...or paste company names / websites (one per line, or a table "
                                          "copied from Sheets/Docs):").grid(row=1, column=0, columnspan=3, sticky="ew")
        self.paste_box = ctk.CTkTextbox(tb, height=70)
        self.paste_box.grid(row=2, column=0, columnspan=3, sticky="ew", pady=4)

        ctl = ctk.CTkFrame(self, fg_color="transparent")
        ctl.grid(row=2, column=0, padx=14, pady=4, sticky="ew")
        self.start_btn = ctk.CTkButton(ctl, text="Start", width=110, command=self._on_start)
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn = ctk.CTkButton(ctl, text="Stop", width=90, fg_color="#B03A2E", hover_color="#8E2E24",
                                      state="disabled", command=self._on_stop)
        self.stop_btn.pack(side="left", padx=4)
        ctk.CTkButton(ctl, text="Export Excel", width=120, fg_color="#1F4E78", hover_color="#173B5A",
                      command=self._on_export).pack(side="left", padx=4)
        ctk.CTkButton(ctl, text="Open Output Folder", width=140, fg_color="gray30",
                      command=self._open_output).pack(side="left", padx=4)
        ctk.CTkButton(ctl, text="Clear History", width=110, fg_color="gray30",
                      command=self._clear_history).pack(side="right", padx=4)
        self.hist_label = ctk.CTkLabel(ctl, text="")
        self.hist_label.pack(side="right", padx=8)
        self._refresh_hist_label()

        mid = ctk.CTkFrame(self)
        mid.grid(row=3, column=0, padx=14, pady=(6, 14), sticky="nsew")
        mid.grid_columnconfigure(0, weight=1)
        mid.grid_rowconfigure(3, weight=1)
        self.status_label = ctk.CTkLabel(mid, text="Idle", anchor="w")
        self.status_label.grid(row=0, column=0, padx=10, pady=(8, 2), sticky="ew")
        self.progress = ctk.CTkProgressBar(mid)
        self.progress.grid(row=1, column=0, padx=10, pady=4, sticky="ew")
        self.progress.set(0)
        self.stats_label = ctk.CTkLabel(mid, text=self._stats_text({}), anchor="w")
        self.stats_label.grid(row=2, column=0, padx=10, pady=2, sticky="ew")
        self.log_box = ctk.CTkTextbox(mid, state="disabled", font=("Consolas", 12))
        self.log_box.grid(row=3, column=0, padx=10, pady=(4, 10), sticky="nsew")

    @staticmethod
    def _stats_text(s):
        g = lambda k: s.get(k, 0)
        return (f"Complete leads: {g('kept')} (decision-maker direct: {g('direct')} | named: {g('named')} | "
                f"company: {g('company')}) | Discarded: {g('rejected')} | Dupes: {g('dupes')} | "
                f"AI calls: {g('ai_calls')} (skipped: {g('ai_skipped')})")

    # ---- thread-safe hooks used by the engine ----
    def log(self, msg):
        self.msg_q.put(("log", f"[{datetime.now():%H:%M:%S}] {msg}"))

    def set_status(self, text):
        self.msg_q.put(("status", text))

    def set_progress(self, done, total):
        self.msg_q.put(("progress", done / max(total, 1)))

    def set_stats(self, s):
        self.msg_q.put(("stats", s))

    def notify(self, text):
        self.msg_q.put(("notify", text))

    def _poll(self):
        try:
            for _ in range(200):
                kind, *payload = self.msg_q.get_nowait()
                if kind == "log":
                    self.log_box.configure(state="normal")
                    self.log_box.insert("end", payload[0] + "\n")
                    if int(self.log_box.index("end-1c").split(".")[0]) > 2500:
                        self.log_box.delete("1.0", "400.0")
                    self.log_box.see("end")
                    self.log_box.configure(state="disabled")
                elif kind == "status":
                    self.status_label.configure(text=payload[0])
                elif kind == "progress":
                    self.progress.set(min(max(payload[0], 0), 1))
                elif kind == "stats":
                    self.stats_label.configure(text=self._stats_text(payload[0]))
                elif kind == "notify":
                    messagebox.showinfo("Lead Finder", payload[0])
                elif kind == "finished":
                    self._set_running(False)
                    self.status_label.configure(text="Finished" if not self.stop_event.is_set() else "Stopped")
                    self._refresh_hist_label()
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _int(self, entry, default, lo, hi):
        try:
            return max(lo, min(hi, int(entry.get().strip())))
        except ValueError:
            return default

    def _save_settings(self):
        self.cfg.update({
            "gemini_key": self.key_entry.get().strip(),
            "model": self.model_entry.get().strip() or "auto",
            "region": (self.region_entry.get().strip() or "US").upper(),
            "respect_robots": bool(self.var_robots.get()),
            "allow_freemail": bool(self.var_free.get()),
            "directory_fallback": bool(self.var_dir.get()),
            "resume": bool(self.var_resume.get()),
            "skip_history_b": bool(self.var_skip_hist.get()),
            "extra_columns": self.extra_entry.get().strip(),
            "workers": self._int(self.workers_entry, DEFAULT_WORKERS, 1, 32),
            "gemini_rpm": self._int(self.rpm_entry, DEFAULT_GEMINI_RPM, 1, 300),
        })
        save_json_atomic(CONFIG_FILE, self.cfg)

    def _choose_file(self):
        path = filedialog.askopenfilename(filetypes=[("Spreadsheets", "*.csv *.xlsx *.xlsm"), ("All files", "*.*")])
        if path:
            self.input_path = path
            self.file_label.configure(text=Path(path).name)

    def _on_start(self):
        if self.worker and self.worker.is_alive():
            return
        self._save_settings()
        if self.tabs.get() == TAB_A:
            prompt = self.prompt_box.get("1.0", "end").strip()
            if not prompt:
                messagebox.showwarning("Lead Finder", "Please enter a search prompt.")
                return
            job = lambda eng: eng.run_search(prompt)
        else:
            rows = []
            try:
                if self.input_path:
                    rows = read_input_file(self.input_path)
                pasted = self.paste_box.get("1.0", "end").strip()
                if pasted:
                    rows += rows_from_pasted(pasted)
            except Exception as e:
                messagebox.showerror("Lead Finder", f"Could not read input: {e}")
                return
            if not rows:
                messagebox.showwarning("Lead Finder", "Choose a file or paste company names/websites first.")
                return
            skip = bool(self.var_skip_hist.get())
            job = lambda eng: eng.run_enrich(rows, skip)

        self.stop_event.clear()
        self.engine = Engine(self.cfg, self.history, self, self.stop_event)
        self.progress.set(0)
        self.stats_label.configure(text=self._stats_text({}))
        self._set_running(True)
        self.worker = threading.Thread(target=self._run_job, args=(job,), daemon=True)
        self.worker.start()

    def _run_job(self, job):
        try:
            job(self.engine)
        except Exception:
            self.log("FATAL ERROR:\n" + traceback.format_exc())
        finally:
            self.msg_q.put(("finished",))

    def _on_stop(self):
        self.stop_event.set()
        self.status_label.configure(text="Stopping - finishing in-flight sites ...")
        self.log("Stop requested - saving progress ...")

    def _on_export(self):
        """Full dataset in ONE clean Excel - live results, or (after a restart) the saved checkpoint."""
        rows, columns, short = [], None, "leads"
        if self.engine and self.engine.snapshot():
            rows, columns, short = self.engine.snapshot(), self.engine.columns, self.engine.short
        else:
            sess = load_json(SESSION_FILE, {})
            if sess.get("ckpt"):
                rows = read_checkpoint(sess["ckpt"])[0]
                columns, short = build_columns([tuple(c) for c in sess.get("custom", [])]), sess.get("short", "leads")
        if not rows:
            messagebox.showinfo("Lead Finder", "No leads to export yet.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")],
                                            initialfile=f"{short}_FULL_{len(rows)}_leads.xlsx")
        if path:
            try:
                export_xlsx(rows, columns, path)
                messagebox.showinfo("Lead Finder", f"Exported all {len(rows)} leads to one file.")
            except Exception as e:
                messagebox.showerror("Lead Finder", f"Export failed: {e}")

    def _check_unfinished(self):
        sess = load_json(SESSION_FILE, {})
        if sess and not sess.get("finished") and Path(sess.get("ckpt", "")).exists():
            n = len(read_checkpoint(sess["ckpt"])[0])
            if sess.get("mode") == "A" and sess.get("prompt"):
                self.prompt_box.delete("1.0", "end")
                self.prompt_box.insert("1.0", sess["prompt"])
                self.log(f"Unfinished run found: {n} leads saved. Press Start to resume from lead #{n + 1}.")
            else:
                self.log(f"Unfinished upload run found: {n} leads saved. Choose the SAME file and press Start to resume.")

    def _open_output(self):
        try:
            if os.name == "nt":
                os.startfile(OUT_DIR)  # noqa
            elif os.uname().sysname == "Darwin":
                os.system(f'open "{OUT_DIR}"')
            else:
                os.system(f'xdg-open "{OUT_DIR}"')
        except Exception:
            messagebox.showinfo("Lead Finder", f"Output folder: {OUT_DIR}")

    def _clear_history(self):
        if messagebox.askyesno("Clear history", "Forget every company scraped so far? "
                                                "Old leads may then be repeated."):
            self.history.clear()
            self._refresh_hist_label()

    def _refresh_hist_label(self):
        self.hist_label.configure(text=f"History: {len(self.history)} companies")

    def _set_running(self, running):
        self.start_btn.configure(state="disabled" if running else "normal")
        self.stop_btn.configure(state="normal" if running else "disabled")

    def _on_close(self):
        self.stop_event.set()
        try:
            self.history.save()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    if ctk is None:
        raise SystemExit("customtkinter / tkinter is not available. Install: pip install customtkinter "
                         "(on Linux also: sudo apt install python3-tk)")
    App().mainloop()
