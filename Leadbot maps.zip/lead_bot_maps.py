"""
Reshalat Lead Finder - GOOGLE MAPS EDITION  (lead_bot_maps.py)
==============================================================
A sibling of lead_bot.py. lead_bot.py is NOT modified - this file imports it and re-uses
its tested engine (site crawler, email/phone validation, history, checkpoints, Excel export,
GUI) and swaps only the DISCOVERY layer:

    old:  DuckDuckGo search  ->  random web pages  ->  crawl
    new:  Google Maps (primary) + OpenStreetMap (parallel, free, block-proof)  ->  crawl

Keep BOTH files in the same folder.   Run:   python lead_bot_maps.py

Data is kept separately from the old bot:  ./data_maps/  and  ./output_maps/
(on the first run your Gemini key / settings are copied over from ./data/config.json).

How it works
------------
1. Google Maps is scrolled slowly like a person (one browser, never parallel). From every
   result card we read: name, website, phone, address, category, rating, Google Maps link.
   Cards without a website are skipped (no site = no email) and remembered in history.
2. OpenStreetMap (Nominatim + Overpass, free) runs in a background thread at the same time.
3. Every website is crawled by the existing 8-worker crawler. Email must come from the
   company's own site; the phone from Google Maps is cross-checked against the site.
4. Block-aware: if Google shows a CAPTCHA (or the per-IP listing budget is reached) the bot
   saves everything, then WAITS FOR A NEW PUBLIC IP (toggle airplane mode - or let it do it
   through ADB), opens a fresh browser and resumes the same query. Crawling of already found
   websites continues while it waits.

Probe test (no crawl, prints what Maps returns):
    python lead_bot_maps.py --probe "dentists in Austin, TX" 50
"""

import json
import random
import re
import shutil
import subprocess
import sys
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qs, quote, urlparse

import requests

import lead_bot as lb

# ---------------------------------------------------------------------------
# Separate data/output folders (the original bot keeps ./data and ./output untouched)
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data_maps"
OUT_DIR = APP_DIR / "output_maps"
for _d in (DATA_DIR, OUT_DIR):
    _d.mkdir(exist_ok=True)

lb.DATA_DIR, lb.OUT_DIR = DATA_DIR, OUT_DIR
lb.HISTORY_FILE = DATA_DIR / "history.json"
lb.CONFIG_FILE = DATA_DIR / "config.json"
lb.SESSION_FILE = DATA_DIR / "session.json"

_old_cfg = APP_DIR / "data" / "config.json"          # first run: inherit Gemini key etc.
if not lb.CONFIG_FILE.exists() and _old_cfg.exists():
    try:
        shutil.copy(_old_cfg, lb.CONFIG_FILE)
    except OSError:
        pass

# Extra Excel columns (inserted before "Contact Level / Verification")
MAPS_COLUMNS = [("category", "Category", "text"),
                ("rating", "Google Rating", "text"),
                ("maps_url", "Google Maps", "url")]
_orig_build_columns = lb.build_columns


def _build_columns_maps(custom):
    cols = _orig_build_columns(custom)
    idx = len(cols) - len(lb.TAIL_COLUMNS)
    return cols[:idx] + MAPS_COLUMNS + cols[idx:]


lb.build_columns = _build_columns_maps

MAPS_DEFAULTS = {
    "use_maps": True,          # Google Maps discovery
    "use_osm": True,           # OpenStreetMap discovery (parallel, free)
    "maps_show_browser": True,  # visible Chrome window is harder to detect than headless
    "maps_per_ip": 150,        # listings scraped per IP before asking for a new one
    "maps_max_per_query": 120,  # Google never gives much more than ~120 per search
    "maps_zip": True,          # add one query per ZIP/postal code (needs: pip install pgeocode)
    "adb_rotate": False,       # change IP automatically through ADB (Android phone on USB)
    "adb_method": "data",      # "data" = toggle mobile data, "airplane" = toggle airplane mode
}
SCROLL_PAUSE = (0.9, 1.8)      # seconds between scrolls in the Maps list
QUERY_PAUSE = (3.0, 7.0)       # seconds between two Maps searches
HARD_WAIT_MIN = 30             # minutes to wait for a new IP after a CAPTCHA
SOFT_WAIT_MIN = 10             # minutes to wait for a new IP when only the budget is reached


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def public_ip():
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=6).text.strip()
            if re.match(r"^[0-9a-fA-F:.]{7,45}$", ip):
                return ip
        except Exception:
            continue
    return None


def beep():
    try:
        import winsound
        for _ in range(3):
            winsound.Beep(1000, 250)
    except Exception:
        print("\a", end="", flush=True)


def adb_rotate(method, log):
    """Toggle mobile data / airplane mode on a USB-connected Android phone. -> True if commands ran."""
    if not shutil.which("adb"):
        log("ADB not found in PATH - install Android platform-tools, or toggle airplane mode yourself.")
        return False
    try:
        dev = subprocess.run(["adb", "devices"], capture_output=True, text=True, timeout=15).stdout
        if not re.search(r"\n\S+\s+device\b", dev):
            log("ADB: no authorised phone found (USB debugging on? accept the prompt on the phone).")
            return False

        def sh(*a):
            return subprocess.run(["adb", "shell", *a], capture_output=True, text=True, timeout=20).returncode

        if method == "airplane":
            rc = sh("cmd", "connectivity", "airplane-mode", "enable")
            time.sleep(4)
            rc2 = sh("cmd", "connectivity", "airplane-mode", "disable")
            ok = rc == 0 and rc2 == 0
        else:
            rc = sh("svc", "data", "disable")
            time.sleep(4)
            rc2 = sh("svc", "data", "enable")
            ok = rc == 0 and rc2 == 0
        log("ADB: connection toggled - waiting for a new IP ..." if ok else "ADB command failed on this phone.")
        return ok
    except Exception as e:
        log(f"ADB error: {str(e)[:100]}")
        return False


def zip_codes(location, country, log):
    """Postal codes of a city (free GeoNames data via pgeocode) -> list[str]. [] if unavailable."""
    if not location:
        return []
    try:
        import pgeocode
    except ImportError:
        log("Tip: pip install pgeocode  -> one Maps query per ZIP code = far more leads per city.")
        return []
    try:
        nomi = pgeocode.Nominatim((country or "us").lower())
        df = getattr(nomi, "_data_frame", None)
        if df is None:
            df = nomi._data
        parts = [p.strip() for p in location.split(",") if p.strip()]
        city = parts[0].lower()
        state = parts[1].lower() if len(parts) > 1 else ""
        sel = df[df["place_name"].astype(str).str.lower() == city]
        if sel.empty:
            sel = df[df["place_name"].astype(str).str.lower().str.contains(re.escape(city), na=False)]
        if state:
            st = sel[(sel.get("state_code", "").astype(str).str.lower() == state)
                     | (sel.get("state_name", "").astype(str).str.lower() == state)]
            sel = st if not st.empty else sel
        out = sorted({str(z).split("-")[0] for z in sel["postal_code"].dropna()})
        return out[:150]
    except Exception as e:
        log(f"ZIP lookup failed ({str(e)[:80]}) - continuing without it.")
        return []


# ---------------------------------------------------------------------------
# OpenStreetMap discovery (free, no CAPTCHA, runs in parallel with Google Maps)
# ---------------------------------------------------------------------------
OSM_TAGS = [
    (r"dent", [("amenity", "dentist"), ("healthcare", "dentist")]),
    (r"salon|hair|barber", [("shop", "hairdresser"), ("shop", "beauty")]),
    (r"spa\b|massage", [("shop", "massage"), ("leisure", "spa")]),
    (r"restaurant", [("amenity", "restaurant")]),
    (r"cafe|coffee", [("amenity", "cafe")]),
    (r"\bbar\b|pub\b", [("amenity", "bar"), ("amenity", "pub")]),
    (r"bak", [("shop", "bakery")]),
    (r"lawyer|attorney|law firm", [("office", "lawyer")]),
    (r"real estate|realtor|estate agen", [("office", "estate_agent")]),
    (r"accountant|\bcpa\b|tax", [("office", "accountant"), ("office", "tax_advisor")]),
    (r"insurance", [("office", "insurance")]),
    (r"plumb", [("craft", "plumber")]),
    (r"electrician", [("craft", "electrician")]),
    (r"hvac|heating|air condition", [("craft", "hvac")]),
    (r"roof", [("craft", "roofer")]),
    (r"paint", [("craft", "painter")]),
    (r"contractor|builder|construction", [("craft", "builder"), ("office", "construction_company")]),
    (r"gym|fitness", [("leisure", "fitness_centre")]),
    (r"vet", [("amenity", "veterinary")]),
    (r"pharmacy", [("amenity", "pharmacy")]),
    (r"optic|optom", [("shop", "optician")]),
    (r"physio", [("healthcare", "physiotherapist")]),
    (r"doctor|clinic|physician|medical", [("amenity", "doctors"), ("amenity", "clinic"),
                                          ("healthcare", "doctor")]),
    (r"auto repair|mechanic|car repair", [("shop", "car_repair")]),
    (r"car dealer", [("shop", "car")]),
    (r"car wash", [("amenity", "car_wash")]),
    (r"hotel|motel", [("tourism", "hotel"), ("tourism", "motel")]),
    (r"florist", [("shop", "florist")]),
    (r"photograph", [("craft", "photographer"), ("shop", "photo")]),
    (r"marketing|advertis", [("office", "advertising_agency")]),
    (r"software|\bit\b|web design", [("office", "it")]),
    (r"architect", [("office", "architect")]),
    (r"dry clean|laundry", [("shop", "dry_cleaning"), ("shop", "laundry")]),
    (r"pet groom", [("shop", "pet_grooming")]),
    (r"school|daycare|child ?care", [("amenity", "childcare"), ("amenity", "kindergarten")]),
]
OSM_HEADERS = {"User-Agent": "ReshalatLeadFinder/1.0 (B2B lead research; contact: local desktop app)"}
OVERPASS = ("https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter")


def osm_tag_pairs(niche):
    n = (niche or "").lower()
    pairs = []
    for pat, tags in OSM_TAGS:
        if re.search(pat, n):
            return list(tags)                  # first (most specific) rule wins
    return pairs


def osm_discover(niche, location, log, stop, limit=1500):
    """-> list of candidate dicts {key,name,website,phone,address,category,rating,maps_url,source}"""
    if not location:
        return []
    try:
        g = requests.get("https://nominatim.openstreetmap.org/search", headers=OSM_HEADERS, timeout=25,
                         params={"q": location, "format": "jsonv2", "limit": 1})
        place = (g.json() or [None])[0]
    except Exception as e:
        log(f"OSM: could not geocode '{location}' ({str(e)[:60]}).")
        return []
    if not place:
        log(f"OSM: location '{location}' not found.")
        return []
    otype, oid = place.get("osm_type"), int(place.get("osm_id", 0))
    if otype == "relation":
        scope = f"(area:{3600000000 + oid})"
    elif otype == "way":
        scope = f"(area:{2400000000 + oid})"
    else:
        s, n, w, e = place["boundingbox"]
        scope = f"({s},{w},{n},{e})"
    pairs = osm_tag_pairs(niche)
    lines = []
    if pairs:
        for k, v in pairs:
            for wk in ("website", "contact:website"):
                lines.append(f'nwr["{k}"="{v}"]["{wk}"]{scope};')
    else:
        words = [re.sub(r"s$", "", w) for w in re.sub(r"[^A-Za-z0-9 ]", " ", niche).split() if len(w) > 3]
        if not words:
            return []
        rx = "|".join(words)
        for wk in ("website", "contact:website"):
            lines.append(f'nwr["name"~"{rx}",i]["{wk}"]{scope};')
    query = f"[out:json][timeout:90];({''.join(lines)});out tags center {limit};"
    data = None
    for url in OVERPASS:
        if stop.is_set():
            return []
        try:
            r = requests.post(url, data={"data": query}, headers=OSM_HEADERS, timeout=120)
            if r.status_code == 200:
                data = r.json()
                break
        except Exception:
            continue
    if not data:
        log("OSM: Overpass did not answer - skipping OpenStreetMap.")
        return []
    city = re.split(r",", location)[0].strip().lower()
    out, seen = [], set()
    for el in data.get("elements", []):
        t = el.get("tags", {})
        site = t.get("website") or t.get("contact:website") or ""
        name = t.get("name", "")
        if not (site and name):
            continue
        ac = (t.get("addr:city") or "").lower()
        if ac and city and city not in ac and ac not in city:
            continue                              # bbox/area spill-over into another town
        if not re.match(r"^https?://", site, re.I):
            site = "http://" + site
        dom = lb.norm_domain(site)
        if dom in seen:
            continue
        seen.add(dom)
        addr = ", ".join(x for x in (
            " ".join(y for y in (t.get("addr:housenumber"), t.get("addr:street")) if y),
            t.get("addr:city"), " ".join(y for y in (t.get("addr:state"), t.get("addr:postcode")) if y)) if x)
        out.append({"key": f"osm:{el.get('type')}/{el.get('id')}", "name": name, "website": site,
                    "phone": (t.get("phone") or t.get("contact:phone") or "").split(";")[0].strip(),
                    "address": addr, "category": "", "rating": "",
                    "maps_url": f"https://www.openstreetmap.org/{el.get('type')}/{el.get('id')}",
                    "source": "osm"})
    log(f"OSM: {len(out)} businesses with a website found for '{niche}' in '{location}'.")
    return out


# ---------------------------------------------------------------------------
# Google Maps browser (sync Playwright, ONE browser, human-like pacing)
# ---------------------------------------------------------------------------
class MapsBlocked(Exception):
    pass


FEED_JS = """
() => {
  const feed = document.querySelector('div[role="feed"]');
  if (!feed) return {feed: false, items: [], end: false};
  const items = [];
  feed.querySelectorAll('a.hfpxzc').forEach(a => {
    const card = a.closest('div.Nv2PK') || a.parentElement;
    const web = card ? card.querySelector('a[data-value="Website"]') : null;
    const ph = card ? card.querySelector('span.UsdlK') : null;
    items.push({name: a.getAttribute('aria-label') || '', href: a.href || '',
                website: web ? web.href : '', phone: ph ? ph.textContent : '',
                text: card ? card.innerText : ''});
  });
  return {feed: true, items: items,
          end: /you.ve reached the end of the list/i.test(feed.innerText || '')};
}
"""
DETAIL_JS = """
() => {
  const h = document.querySelector('h1.DUwDvf');
  if (!h) return null;
  const w = document.querySelector('a[data-item-id="authority"]');
  const p = document.querySelector('button[data-item-id^="phone:tel:"]');
  const a = document.querySelector('button[data-item-id="address"]');
  const c = document.querySelector('button.DkEaL');
  return {name: h.textContent.trim(), website: w ? w.href : '',
          phone: p ? (p.getAttribute('data-item-id') || '').replace('phone:tel:', '') : '',
          address: a ? (a.getAttribute('aria-label') || '').replace(/^Address:\\s*/, '') : '',
          category: c ? c.textContent.trim() : '', text: document.body.innerText.slice(0, 600)};
}
"""
SCROLL_END_JS = ("() => {const f = document.querySelector('div[role=\"feed\"]');"
                 " if (f) f.scrollTo(0, f.scrollHeight);}")
STREET_RE = re.compile(r"\b(st|street|ave|avenue|rd|road|blvd|boulevard|dr|drive|ln|lane|way|ct|court|"
                       r"pkwy|hwy|suite|ste|plaza|pl|sq)\b\.?", re.I)


def clean_google_url(u):
    u = (u or "").strip()
    if not u:
        return ""
    p = urlparse(u)
    if "google." in p.netloc and p.path in ("/url", "/aclk"):
        q = parse_qs(p.query)
        u = (q.get("q") or q.get("adurl") or [""])[0]
        p = urlparse(u)
    if not re.match(r"^https?://", u, re.I) or "google." in p.netloc:
        return ""
    return u


def parse_card(it):
    """Raw card from the page -> normalised candidate dict (or None)."""
    name = re.sub(r"\s+", " ", (it.get("name") or "")).strip()
    if not name:
        return None
    href = it.get("href") or ""
    m = re.search(r"!1s(0x[0-9a-f]+:0x[0-9a-f]+)", href)
    pm = re.search(r"/maps/place/([^/@?]+)", href)
    key = m.group(1) if m else (pm.group(1) if pm else name.lower())
    text = it.get("text") or ""
    phone = (it.get("phone") or "").strip()
    if not phone:
        pm2 = lb.PHONE_RE.search(text)
        phone = pm2.group(0) if pm2 else ""
    rating = ""
    rm = re.search(r"(\d\.\d)\s*\(?\s*([\d,]+)\s*\)?", text)
    if rm:
        rating = f"{rm.group(1)} ({rm.group(2)} reviews)"
    category, address = it.get("category", ""), it.get("address", "")
    for line in [l.strip() for l in text.split("\n") if l.strip()]:
        if "\u00b7" not in line:
            continue
        parts = [p.strip() for p in line.split("\u00b7") if p.strip()]
        if not category and parts and not re.match(r"^\d", parts[0]):
            category = parts[0]
        for p in parts[1:] if category == parts[0] else parts:
            if not address and (re.match(r"^\d", p) or STREET_RE.search(p)):
                address = p
    category = re.sub(r"[^\w)]+$", "", category).strip()
    return {"key": key, "name": name, "website": clean_google_url(it.get("website")), "phone": phone,
            "address": address, "category": category, "rating": rating,
            "maps_url": href if href.startswith("http") else "", "source": "maps"}


class MapsBrowser:
    def __init__(self, cfg, log, stop):
        self.cfg, self.log, self.stop = cfg, log, stop
        self.pw = self.browser = self.ctx = self.page = None
        self.pace = 1.0                      # >1 = slower (used when we keep the same IP)
        self.snap_done = False

    def start(self):
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start()
        headless = not self.cfg.get("maps_show_browser", True)
        args = ["--disable-blink-features=AutomationControlled", "--lang=en-US"]
        last = None
        for kw in ({"channel": "chrome"}, {}):         # real Chrome first, bundled Chromium as fallback
            try:
                self.browser = self.pw.chromium.launch(headless=headless, args=args, **kw)
                break
            except Exception as e:
                last = e
        if self.browser is None:
            raise RuntimeError(f"Could not start a browser: {last}. Run: playwright install chromium")
        self.ctx = self.browser.new_context(locale="en-US", viewport={"width": 1280, "height": 900})
        self.ctx.route("**/*", lambda r: r.abort()
                       if r.request.resource_type in ("image", "media", "font") else r.continue_())
        self.page = self.ctx.new_page()

    def close(self):
        for obj, meth in ((self.ctx, "close"), (self.browser, "close"), (self.pw, "stop")):
            try:
                if obj:
                    getattr(obj, meth)()
            except Exception:
                pass
        self.pw = self.browser = self.ctx = self.page = None

    # ---- page state ----
    def _blocked(self):
        p = self.page
        try:
            if "/sorry" in p.url:
                return True
            if p.locator('iframe[src*="recaptcha"], form#captcha-form').count() > 0:
                return True
            body = p.inner_text("body", timeout=3000)[:3000].lower()
            return "unusual traffic" in body or "not a robot" in body
        except Exception:
            return False

    def _consent(self):
        p = self.page
        try:
            if "consent.google" in p.url:
                p.get_by_role("button", name=re.compile(r"accept all|reject all|i agree", re.I)).first.click(timeout=6000)
                p.wait_for_url(re.compile(r"google\.[a-z.]+/maps"), timeout=15000)
        except Exception:
            pass

    def _snapshot(self, why):
        if self.snap_done:
            return
        self.snap_done = True
        try:
            self.page.screenshot(path=str(DATA_DIR / "debug_maps.png"))
            (DATA_DIR / "debug_maps.html").write_text(self.page.content()[:600000], encoding="utf-8")
            self.log(f"Saved debug snapshot ({why}): data_maps/debug_maps.png + debug_maps.html")
        except Exception:
            pass

    def _scroll(self, stale):
        try:
            self.page.mouse.move(random.randint(150, 320), random.randint(260, 620))
            if stale >= 2:
                self.page.evaluate(SCROLL_END_JS)
            else:
                self.page.mouse.wheel(0, random.randint(900, 1700))
        except Exception:
            pass

    def _pause(self):
        d = random.uniform(*SCROLL_PAUSE)
        if random.random() < 0.08:
            d += random.uniform(3, 6)          # an occasional longer "reading" pause
        lb.sleep_stop(d * self.pace, self.stop)

    # ---- main generator ----
    def search(self, query, max_results):
        """Yield candidate dicts while scrolling. Raises MapsBlocked on CAPTCHA."""
        gl = (self.cfg.get("region") or "US").lower()
        p = self.page
        try:
            p.goto(f"https://www.google.com/maps/search/{quote(query)}?hl=en&gl={gl}",
                   wait_until="domcontentloaded", timeout=45000)
        except Exception as e:
            if self._blocked():
                raise MapsBlocked("blocked while loading")
            raise RuntimeError(f"page load failed: {str(e)[:80]}")
        if self._blocked():
            raise MapsBlocked("CAPTCHA page")
        self._consent()
        try:
            p.wait_for_selector('div[role="feed"], h1.DUwDvf', timeout=20000)
        except Exception:
            if self._blocked():
                raise MapsBlocked("CAPTCHA / unusual-traffic page")
            self._snapshot("no result list")
            return
        seen, stale, yielded = set(), 0, 0
        while not self.stop.is_set():
            try:
                data = p.evaluate(FEED_JS)
            except Exception:
                if self._blocked():
                    raise MapsBlocked("page replaced by a block page")
                return
            if not data["feed"]:                       # exactly one match -> place page opened directly
                d = p.evaluate(DETAIL_JS)
                if d and d.get("name"):
                    d["href"] = p.url
                    c = parse_card(d)
                    if c:
                        yield c
                elif self._blocked():
                    raise MapsBlocked("block page")
                return
            new = 0
            for it in data["items"]:
                c = parse_card(it)
                if not c or c["key"] in seen:
                    continue
                seen.add(c["key"])
                new += 1
                yielded += 1
                yield c
                if yielded >= max_results:
                    return
            if yielded >= 8 and not self.snap_done and not any(
                    parse_card(i) and parse_card(i)["website"] for i in data["items"]):
                self.log("WARNING: no website found on any card - Google may have changed its layout.")
                self._snapshot("cards without website")
            if data["end"]:
                return
            stale = 0 if new else stale + 1
            if stale >= 5:
                return
            self._scroll(stale)
            self._pause()
            if "/sorry" in p.url:
                raise MapsBlocked("redirected to CAPTCHA")


# ---------------------------------------------------------------------------
# Engine: original engine + Maps/OSM discovery + block-aware resume
# ---------------------------------------------------------------------------
_BaseEngine = lb.Engine


class MapsEngine(_BaseEngine):
    def __init__(self, cfg, history, ui, stop_event):
        for k, v in MAPS_DEFAULTS.items():
            cfg.setdefault(k, v)
        super().__init__(cfg, history, ui, stop_event)
        self.tl = threading.local()
        self.sub_lock = threading.Lock()
        self.force_resume = threading.Event()
        self.browser = None
        self.ip, self.ip_count, self.maps_gave_up = None, 0, False
        self.stats.update({"maps_seen": 0, "maps_nosite": 0, "osm": 0})

    # ---- record assembly: Google Maps phone/address/category + cross-check ----
    def compose(self, crawl, row=None):
        rec = super().compose(crawl, row)
        m = (row or {}).get("_maps")
        if not m:
            return rec
        rec["category"], rec["rating"], rec["maps_url"] = m.get("category", ""), m.get("rating", ""), m.get("maps_url", "")
        if m.get("address"):
            rec["address"] = m["address"]
        label = "Google Maps" if m.get("source") == "maps" else "OpenStreetMap"
        mp = lb.normalize_phone(m.get("phone", ""), self.crawler.region)
        if mp:
            site_phone = rec["phone"]
            sd = re.sub(r"\D", "", site_phone)[-10:]
            md = re.sub(r"\D", "", mp)[-10:]
            rec["phone"] = mp
            if not site_phone:
                src = f"{label} listing"
            elif sd == md:
                src = f"company website + {label} (match)"
            else:
                src = f"{label} listing (website shows a different number: {site_phone})"
            rec["verification"] = re.sub(r"Phone: .*$", lambda _: f"Phone: {src}", rec["verification"])
        return rec

    def directory_phone(self, name, domain, location):
        c = getattr(self.tl, "cand", None)
        if c and lb.normalize_phone(c.get("phone", ""), self.crawler.region):
            return ""                         # we already have a Maps phone - skip the DDG fallback
        return super().directory_phone(name, domain, location)

    # ---- query planning ----
    def _plan_queries(self, niche, location, expansion):
        niches = [niche] + [s for s in expansion.get("niche_synonyms", []) if s.lower() != niche.lower()][:3]
        areas = expansion.get("areas", [])
        zips = zip_codes(location, self.cfg.get("region", "US"), self.log) if self.cfg.get("maps_zip", True) else []
        qs = [f"{niche} in {location}" if location else niche]
        for a in areas:
            qs.append(f"{niche} in {a}" + (f", {location}" if location and location.lower() not in a.lower() else ""))
        qs += [f"{niche} {z}" for z in zips]
        for n in niches[1:]:
            qs.append(f"{n} in {location}" if location else n)
            qs += [f"{n} in {a}" for a in areas[:10]]
        out, seen = [], set()
        for q in qs:
            q = re.sub(r"\s+", " ", q).strip()
            if q.lower() not in seen:
                seen.add(q.lower())
                out.append(q)
        return out

    # ---- candidate intake (thread-safe: Maps thread + OSM thread both call this) ----
    def _submit_cand(self, cand, ctx):
        """-> 'stop' | 'dupe' | 'nosite' | 'submitted'"""
        if self.stop.is_set() or self.count() >= self.target:
            return "stop"
        site = cand.get("website", "")
        dom = lb.norm_domain(site) if site else ""
        with self.sub_lock:
            self.stats["maps_seen" if cand.get("source") == "maps" else "osm"] += 1
            if not dom or lb.is_blocked_host(dom):
                hk = "gm:" + cand["key"]
                if not self.history.seen(hk):
                    self.history.add(hk, {"name": cand["name"], "note": "no own website"})
                    self.stats["maps_nosite"] += 1
                return "nosite"
            if dom in ctx.session_keys or self.history.seen(dom):
                self.stats["dupes"] += 1
                return "dupe"
            ctx.session_keys.add(dom)
        got = False
        while not self.stop.is_set() and self.count() < self.target:
            if ctx.sem.acquire(timeout=0.5):
                got = True
                break
        if not got:
            return "stop"
        fut = ctx.ex.submit(self._cand_task, cand, dom, ctx.niche, ctx.location)
        fut.add_done_callback(lambda f: ctx.sem.release())
        return "submitted"

    def _cand_task(self, cand, domain, niche, location):
        try:
            if self.stop.is_set() or self.count() >= self.target:
                return
            self.tl.cand = cand
            self.ui.set_status(f"Crawling {domain} ({self.count()}/{self.target})")
            self.log(f"VISIT: {domain}  [{cand['name']}]")
            website = lb.root_url(cand["website"])
            row = {"business_name": cand["name"], "website": website, "_maps": cand}
            meta = self.process_site(website, name_hint=cand["name"], row=row, location=location) or {}
            if not (self.stop.is_set() or meta.get("offline") or meta.get("aborted")):
                self.history.add(domain, {"name": meta.get("name", cand["name"]), "niche": niche,
                                          "location": location, "source": cand.get("source", "maps"),
                                          "date": datetime.now().strftime("%Y-%m-%d")})
                self._mark_done(domain)
                self._tick_history()
        except Exception as e:
            self.log(f"   error on {domain}: {str(e)[:120]}")
        finally:
            self.tl.cand = None
            self.ui.set_progress(self.count(), self.target)

    # ---- OSM thread ----
    def _osm_phase(self, ctx):
        try:
            items = osm_discover(ctx.niche, ctx.location, self.log, self.stop)
            for cand in items:
                if self._submit_cand(cand, ctx) == "stop":
                    break
        except Exception as e:
            self.log(f"OSM error: {str(e)[:100]}")

    # ---- IP rotation / block handling ----
    def _wait_new_ip(self, old, minutes):
        end = time.time() + minutes * 60
        need_offline, seen_offline = old is None, False
        while time.time() < end and not self.stop.is_set():
            if self.force_resume.is_set():
                self.force_resume.clear()
                self.ip = public_ip() or old
                return True
            ip = public_ip()
            if ip is None:
                seen_offline = True
            elif ip != old and (not need_offline or seen_offline):
                lb.sleep_stop(3, self.stop)
                self.ip = ip
                self.log(f"New IP detected ({ip}) - resuming Google Maps.")
                return True
            left = int(end - time.time())
            self.ui.set_status(f"Waiting for a NEW IP - toggle airplane mode ({left // 60}m {left % 60:02d}s left) "
                               f"| websites keep being crawled")
            lb.sleep_stop(6, self.stop)
        return False

    def _handle_block(self, hard):
        why = ("Google showed a CAPTCHA / unusual-traffic page" if hard
               else f"IP budget reached ({self.ip_count} listings)")
        self.log(f"{why}. Progress is saved.")
        try:
            self.history.save()
            self._session_write(False)
        except Exception:
            pass
        old = self.ip or public_ip()
        self.browser.close()
        rotated = bool(self.cfg.get("adb_rotate")) and adb_rotate(self.cfg.get("adb_method", "data"), self.log)
        if not rotated:
            self.log("ACTION NEEDED: switch airplane mode ON then OFF on the phone (new IP). "
                     "Or press 'Resume now' if you changed networks.")
            beep()
        self.force_resume.clear()
        ok = self._wait_new_ip(old, HARD_WAIT_MIN if hard else SOFT_WAIT_MIN)
        if self.stop.is_set():
            return False
        if ok:
            self.ip_count = 0
            self.browser.pace = 1.0
        elif hard:
            self.log("No new IP appeared in time - Google Maps paused. Run again later with the SAME prompt "
                     "to continue where you stopped.")
            return False
        else:
            self.log("No new IP - continuing with the same IP at a slower pace.")
            self.ip_count = 0
            self.browser.pace = 2.0
        self.browser.start()
        return True

    # ---- Google Maps thread (= the run_search thread) ----
    def _maps_phase(self, ctx, queries):
        self.browser = MapsBrowser(self.cfg, self.log, self.stop)
        budget = int(self.cfg.get("maps_per_ip", 150) or 150)
        per_query = int(self.cfg.get("maps_max_per_query", 120) or 120)
        self.ip = public_ip()
        self.log(f"Google Maps mode | current IP: {self.ip or 'unknown'} | budget {budget} listings per IP")
        try:
            self.browser.start()
            qq, fails = deque(queries), {}
            while qq and not self.stop.is_set() and self.count() < self.target:
                q = qq.popleft()
                if self.history.query_exhausted(q):
                    continue
                self.ui.set_status(f"Google Maps: {q}")
                self.log(f"MAPS: {q}")
                submitted, broke = 0, False
                try:
                    for cand in self.browser.search(q, per_query):
                        r = self._submit_cand(cand, ctx)
                        self.ip_count += 1
                        if r == "stop":
                            broke = True
                            break
                        submitted += r == "submitted"
                    self._push_stats()
                except MapsBlocked:
                    if not self._handle_block(hard=True):
                        self.maps_gave_up = not self.stop.is_set()
                        break
                    qq.appendleft(q)
                    continue
                except Exception as e:
                    fails[q] = fails.get(q, 0) + 1
                    self.log(f"   Maps error on '{q}': {str(e)[:100]}")
                    if fails[q] < 2:
                        qq.append(q)
                        self.browser.close()
                        try:
                            self.browser.start()
                        except Exception as e2:
                            self.log(f"Browser restart failed: {str(e2)[:100]}")
                            break
                    continue
                if not broke and submitted == 0:
                    self.history.mark_exhausted(q)
                if qq and self.ip_count >= budget and self.count() < self.target:
                    if not self._handle_block(hard=False):
                        break
                lb.sleep_range(QUERY_PAUSE, self.stop)
        finally:
            self.browser.close()

    # ---------------- Mode A (replaces DuckDuckGo discovery) ----------------
    def run_search(self, prompt):
        try:
            self.ui.set_status("Parsing request ...")
            parsed = self.gemini.parse_prompt(prompt) if self.gemini.enabled else None
            if not parsed:
                parsed = lb.regex_parse_prompt(prompt)
                self.log("Prompt parsed with built-in parser" + ("" if self.gemini.enabled else " (no Gemini key)."))
            niche, location = parsed["niche"], parsed["location"]
            self.target = max(1, int(parsed["count"]))
            if not niche:
                self.log("Could not detect a niche. Example: '200 dental clinics in Chicago, IL'.")
                self.ui.notify("Could not detect a niche in your prompt.")
                return
            extra = list(parsed.get("columns") or []) + [c.strip() for c in str(self.cfg.get("extra_columns", "")).split(",") if c.strip()]
            self.set_custom_columns(extra)
            self._begin_session("A", prompt, prompt, lb.short_prompt(prompt))
            self.target = max(1, int(parsed["count"]))
            self._session_write(False)
            self.log(f"Target: {self.target} x '{niche}' in '{location or 'anywhere'}' | workers: {self.workers}")
            self.log("Columns: " + ", ".join(c[1] for c in self.columns))
            expansion = {"niche_synonyms": [], "areas": []}
            if self.gemini.enabled and self.cfg.get("use_maps", True):
                self.ui.set_status("Planning search variations ...")
                expansion = self.gemini.suggest_expansion(niche, location)
            queries = self._plan_queries(niche, location, expansion)
            if self.cfg.get("use_maps", True):
                self.log(f"{len(queries)} Google Maps searches planned.")
            ctx = SimpleNamespace(session_keys=set(), sem=threading.BoundedSemaphore(self.workers * 2),
                                  ex=ThreadPoolExecutor(max_workers=self.workers), niche=niche, location=location)
            osm_t = None
            try:
                if self.cfg.get("use_osm", True) and location:
                    osm_t = threading.Thread(target=self._osm_phase, args=(ctx,), daemon=True)
                    osm_t.start()
                if self.cfg.get("use_maps", True):
                    self._maps_phase(ctx, queries)
                if osm_t:
                    osm_t.join()
                if not self.stop.is_set() and self.count() < self.target:
                    ctx.ex.shutdown(wait=True)             # let in-flight sites finish before judging
                    if self.maps_gave_up:
                        msg = (f"Google Maps blocked this IP and no new one appeared. {self.count()} of "
                               f"{self.target} leads saved. Run again with the SAME prompt to continue.")
                    elif self.count() < self.target:
                        msg = (f"Search area exhausted: {self.count()} of {self.target} complete leads "
                               "(leads without email or phone are discarded by design). Try a nearby location, "
                               "a broader niche, or add a Gemini key / pgeocode for more search variations.")
                    else:
                        msg = ""
                    if msg:
                        self.log(msg)
                        self.ui.notify(msg)
            finally:
                ctx.ex.shutdown(wait=True, cancel_futures=bool(self.stop.is_set() or self.count() >= self.target))
                self.finished_ok = self.count() >= self.target or (not self.stop.is_set() and not self.maps_gave_up)
        finally:
            self._session_write(self.finished_ok)
            self._close()
            self._finalize()


lb.Engine = MapsEngine          # the GUI of lead_bot.py now creates MapsEngine


# ---------------------------------------------------------------------------
# GUI: original window + a "Google Maps options" strip
# ---------------------------------------------------------------------------
_AppBase = lb.App


class MapsApp(_AppBase):
    def __init__(self):
        super().__init__()
        self.title("Reshalat Lead Finder - Google Maps Edition")

    @staticmethod
    def _stats_text(s):
        g = lambda k: s.get(k, 0)
        return (lb.App._stats_text(s) + f" | Maps listings: {g('maps_seen')} (no website: {g('maps_nosite')}) "
                                        f"| OSM: {g('osm')}")

    def _build_ui(self):
        for k, v in MAPS_DEFAULTS.items():
            self.cfg.setdefault(k, v)
        super()._build_ui()
        ctk = lb.ctk
        box = ctk.CTkFrame(self)
        box.grid(row=4, column=0, padx=14, pady=(0, 12), sticky="ew")
        self.var_maps = ctk.BooleanVar(value=self.cfg["use_maps"])
        self.var_osm = ctk.BooleanVar(value=self.cfg["use_osm"])
        self.var_show = ctk.BooleanVar(value=self.cfg["maps_show_browser"])
        self.var_zip = ctk.BooleanVar(value=self.cfg["maps_zip"])
        self.var_adb = ctk.BooleanVar(value=self.cfg["adb_rotate"])
        ctk.CTkLabel(box, text="Google Maps options:", text_color="#7FB3FF").grid(row=0, column=0, padx=8, pady=6)
        for i, (txt, var) in enumerate((("Google Maps", self.var_maps), ("OpenStreetMap", self.var_osm),
                                        ("Show browser", self.var_show), ("ZIP-code searches", self.var_zip),
                                        ("ADB auto IP change", self.var_adb)), start=1):
            ctk.CTkCheckBox(box, text=txt, variable=var).grid(row=0, column=i, padx=6, pady=6)
        ctk.CTkLabel(box, text="Listings per IP:").grid(row=0, column=6, padx=(12, 2))
        self.ip_entry = ctk.CTkEntry(box, width=60)
        self.ip_entry.grid(row=0, column=7, padx=2)
        self.ip_entry.insert(0, str(self.cfg["maps_per_ip"]))
        self.adb_menu = ctk.CTkOptionMenu(box, values=["data", "airplane"], width=100)
        self.adb_menu.set(self.cfg["adb_method"])
        self.adb_menu.grid(row=0, column=8, padx=6)
        ctk.CTkButton(box, text="Resume now", width=100, fg_color="gray30",
                      command=self._resume_now).grid(row=0, column=9, padx=6)

    def _resume_now(self):
        if self.engine is not None:
            self.engine.force_resume.set()
            self.log("Resume requested - skipping the IP check.")

    def _save_settings(self):
        super()._save_settings()
        try:
            n = max(20, min(2000, int(self.ip_entry.get().strip())))
        except ValueError:
            n = MAPS_DEFAULTS["maps_per_ip"]
        self.cfg.update({"use_maps": bool(self.var_maps.get()), "use_osm": bool(self.var_osm.get()),
                         "maps_show_browser": bool(self.var_show.get()), "maps_zip": bool(self.var_zip.get()),
                         "adb_rotate": bool(self.var_adb.get()), "adb_method": self.adb_menu.get(),
                         "maps_per_ip": n})
        lb.save_json_atomic(lb.CONFIG_FILE, self.cfg)


# ---------------------------------------------------------------------------
# Probe: see what Google Maps returns, without crawling (first test to run)
# ---------------------------------------------------------------------------
def probe(query, n):
    stop = threading.Event()
    cfg = dict(MAPS_DEFAULTS)
    cfg.update(lb.load_json(lb.CONFIG_FILE, {}))
    br = MapsBrowser(cfg, print, stop)
    t0, rows = time.time(), []
    br.start()
    try:
        for c in br.search(query, n):
            rows.append(c)
            print(f"{len(rows):3d}. {c['name'][:38]:38} | {c['phone'] or '-':18} | {c['website'] or '(no website)'}")
    except MapsBlocked as e:
        print(f"\nBLOCKED by Google: {e}")
    finally:
        br.close()
    dt = time.time() - t0
    with_site = sum(1 for r in rows if r["website"])
    print(f"\n{len(rows)} listings in {dt:.0f}s ({dt / max(len(rows), 1):.1f}s each) | with website: {with_site} | "
          f"with phone: {sum(1 for r in rows if r['phone'])}")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--probe":
        probe(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 50)
        raise SystemExit
    if lb.ctk is None:
        raise SystemExit("customtkinter / tkinter is not available. Install: pip install customtkinter "
                         "(on Linux also: sudo apt install python3-tk)")
    MapsApp().mainloop()
